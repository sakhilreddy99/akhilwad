# PlatePilot – NutriNinja Cup

A responsive, frontend-only student diet planner built with **HTML5, CSS3 and Vanilla JavaScript (ES6+)**. Chart.js is used for the interactive macronutrient doughnut chart.

## Run the project
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Edge or Firefox.
3. Internet is needed only for the Chart.js CDN and optional Google Fonts. The application data and planner logic run locally in the browser.

## Features implemented

### Core requirements
- Student profile with daily budget, vegetarian / non-vegetarian / vegan preference, and weight-loss / muscle-gain / maintenance goal.
- Local price-index slider (80%–130%) to model regional price variation.
- 50 affordable Indian-staple recipe records with meal slot, diet type, estimated cost, calories, protein, carbs, fats, preparation time, ingredients and cooking steps.
- Exhaustive four-slot combination search (breakfast, lunch, snack, dinner). Every candidate combination is checked against the selected daily budget; no over-budget plan is returned.
- Nutrition dashboard with calorie and macro totals, interactive Chart.js visualization, and illustrative goal comparisons.
- Expandable per-meal ingredient cost breakdown and hostel-friendly cooking instructions.
- One-click meal swap that checks diet compatibility, nutritional similarity and the remaining daily budget.
- Categorized seven-day grocery consolidation with estimated quantities and costs.
- Local browser persistence for the profile, daily plan, weekly plan and community submissions.

### Stretch requirements
- Seven-day meal calendar with variety preference and a daily budget check for each day.
- Print / Save as PDF using the browser print dialog.
- Pantry leftover matching.
- Hostel mess plate suggestions.
- Community budget recipe board with browser-local submissions.

## Architecture
- `index.html` – page structure, forms and dashboard sections.
- `style.css` – responsive dark interface, cards, mobile layouts and print styles.
- `app.js` – 50-recipe local dataset, budget optimizer, swaps, nutrition chart, grocery aggregation, weekly calendar and localStorage persistence.

## Important limitations
- This is intentionally frontend-only: no Node.js/Express server, external database, authentication or multi-user synchronization is included.
- Recipe prices, ingredient allocations and nutrition values are estimates for demonstration; update them with verified local prices and nutrition references before real-world use.
- Daily energy and macro targets are illustrative goal presets, not individualized medical recommendations. A plan may fall short of a target when the selected budget and available recipe data cannot support it. The app displays the actual totals rather than claiming that every target is met.
- The weekly calendar attempts to avoid repeating recipes while preserving the budget; if the available options are limited, it may reuse recipes.

## Demo suggestion
Set the budget to **₹120/day**, choose **Any preference** and **Muscle gain / High protein**, then select **Generate my plan**. Expand a meal to show its ingredient estimate and cooking method, try a budget-compatible swap, generate the 7-day calendar, and use **Print / save PDF**.
