const $ = (id) => document.getElementById(id);
const recipes = [
 {id:1,name:"Oats, banana & milk",slot:"breakfast",diet:"vegetarian",cost:24,kcal:350,p:13,c:59,f:8,time:8,emoji:"🥣",ingredients:[["oats",40],["banana",1],["milk",150]],steps:"Cook oats in milk for 4–5 minutes. Top with sliced banana and a few peanuts.",protein:"medium"},
 {id:2,name:"Egg bhurji & roti",slot:"breakfast",diet:"nonveg",cost:35,kcal:410,p:23,c:42,f:15,time:12,emoji:"🍳",ingredients:[["eggs",2],["roti",2],["onion",0.5],["tomato",0.5]],steps:"Scramble eggs with onion, tomato and spices. Serve with warm rotis.",protein:"high"},
 {id:3,name:"Moong dal chilla",slot:"breakfast",diet:"vegan",cost:22,kcal:320,p:18,c:43,f:7,time:15,emoji:"🥞",ingredients:[["moong dal",60],["onion",0.3],["tomato",0.3]],steps:"Soak and grind moong dal. Mix chopped vegetables and cook thin pancakes on a pan.",protein:"high"},
 {id:4,name:"Peanut butter toast",slot:"breakfast",diet:"vegan",cost:25,kcal:370,p:13,c:43,f:17,time:5,emoji:"🍞",ingredients:[["bread",2],["peanut butter",25],["banana",0.5]],steps:"Spread peanut butter over toasted bread. Add banana slices.",protein:"medium"},
 {id:5,name:"Poha with peanuts",slot:"breakfast",diet:"vegan",cost:18,kcal:310,p:8,c:51,f:9,time:12,emoji:"🍋",ingredients:[["poha",70],["peanuts",15],["onion",0.3],["potato",0.5]],steps:"Rinse poha. Temper mustard, onion and potato; fold in poha and peanuts.",protein:"low"},
 {id:6,name:"Sprouts chaat",slot:"breakfast",diet:"vegan",cost:20,kcal:280,p:16,c:42,f:5,time:7,emoji:"🥗",ingredients:[["sprouts",100],["onion",0.3],["tomato",0.3],["lemon",0.5]],steps:"Mix steamed sprouts with chopped onion, tomato, lemon and chaat masala.",protein:"high"},
 {id:7,name:"Idli & sambar",slot:"breakfast",diet:"vegan",cost:25,kcal:330,p:12,c:62,f:4,time:10,emoji:"🍘",ingredients:[["idli",3],["sambar",150]],steps:"Steam or reheat idlis. Serve with hot sambar.",protein:"medium"},
 {id:8,name:"Besan vegetable cheela",slot:"breakfast",diet:"vegan",cost:19,kcal:300,p:14,c:39,f:8,time:12,emoji:"🥘",ingredients:[["besan",60],["onion",0.3],["tomato",0.3]],steps:"Make a pourable besan batter with water and vegetables. Cook both sides.",protein:"high"},
 {id:9,name:"Curd & banana bowl",slot:"breakfast",diet:"vegetarian",cost:20,kcal:260,p:10,c:43,f:5,time:3,emoji:"🍌",ingredients:[["curd",150],["banana",1],["roasted chana",15]],steps:"Combine curd and banana. Add roasted chana for crunch.",protein:"medium"},
 {id:10,name:"Upma with peas",slot:"breakfast",diet:"vegan",cost:20,kcal:315,p:9,c:52,f:8,time:12,emoji:"🥣",ingredients:[["rava",65],["peas",25],["onion",0.3]],steps:"Roast rava. Cook vegetables with water, add rava and stir until fluffy.",protein:"low"},
 {id:11,name:"Dal rice bowl",slot:"lunch",diet:"vegan",cost:30,kcal:490,p:18,c:82,f:8,time:20,emoji:"🍚",ingredients:[["rice",75],["toor dal",45],["onion",0.3],["tomato",0.3]],steps:"Pressure cook dal with tomato and spices. Serve over steamed rice.",protein:"high"},
 {id:12,name:"Soya chunks curry & rice",slot:"lunch",diet:"vegan",cost:40,kcal:540,p:32,c:78,f:9,time:22,emoji:"🍛",ingredients:[["soya chunks",45],["rice",65],["onion",0.5],["tomato",0.5]],steps:"Boil and squeeze soya chunks. Simmer in onion-tomato masala; serve with rice.",protein:"high"},
 {id:13,name:"Chana masala & roti",slot:"lunch",diet:"vegan",cost:32,kcal:500,p:19,c:76,f:10,time:20,emoji:"🫘",ingredients:[["chickpeas",65],["roti",2],["onion",0.3],["tomato",0.3]],steps:"Cook boiled chickpeas in a simple onion-tomato spice gravy. Eat with rotis.",protein:"high"},
 {id:14,name:"Egg curry & rice",slot:"lunch",diet:"nonveg",cost:42,kcal:560,p:25,c:73,f:16,time:20,emoji:"🍲",ingredients:[["eggs",2],["rice",65],["onion",0.5],["tomato",0.5]],steps:"Boil eggs. Prepare quick tomato-onion gravy and simmer eggs in it. Serve with rice.",protein:"high"},
 {id:15,name:"Rajma rice",slot:"lunch",diet:"vegan",cost:36,kcal:520,p:19,c:88,f:7,time:25,emoji:"🫘",ingredients:[["rajma",60],["rice",65],["onion",0.3],["tomato",0.3]],steps:"Pressure cook soaked rajma until soft. Simmer with masala and serve with rice.",protein:"high"},
 {id:16,name:"Moong dal khichdi",slot:"lunch",diet:"vegan",cost:26,kcal:430,p:16,c:75,f:6,time:18,emoji:"🥘",ingredients:[["rice",45],["moong dal",45],["carrot",0.3]],steps:"Pressure cook rice and moong dal with turmeric, salt and vegetables.",protein:"medium"},
 {id:17,name:"Paneer bhurji & roti",slot:"lunch",diet:"vegetarian",cost:48,kcal:520,p:27,c:48,f:21,time:15,emoji:"🧀",ingredients:[["paneer",70],["roti",2],["onion",0.3],["tomato",0.3]],steps:"Crumble paneer into onion-tomato masala. Serve with rotis.",protein:"high"},
 {id:18,name:"Vegetable pulao & raita",slot:"lunch",diet:"vegetarian",cost:32,kcal:450,p:12,c:76,f:10,time:18,emoji:"🍚",ingredients:[["rice",75],["mixed vegetables",60],["curd",80]],steps:"Cook rice with mixed vegetables and spices. Serve with seasoned curd.",protein:"medium"},
 {id:19,name:"Peanut lemon rice",slot:"lunch",diet:"vegan",cost:24,kcal:440,p:12,c:70,f:13,time:12,emoji:"🍋",ingredients:[["rice",75],["peanuts",20],["lemon",0.5]],steps:"Temper peanuts and spices, fold in cooked rice and finish with lemon.",protein:"medium"},
 {id:20,name:"Fish curry & rice",slot:"lunch",diet:"nonveg",cost:55,kcal:520,p:31,c:66,f:12,time:25,emoji:"🐟",ingredients:[["fish",90],["rice",65],["tomato",0.5]],steps:"Simmer fish pieces gently in a spiced tomato gravy. Serve with rice.",protein:"high"},
 {id:21,name:"Roasted chana",slot:"snack",diet:"vegan",cost:10,kcal:180,p:9,c:27,f:3,time:1,emoji:"🥜",ingredients:[["roasted chana",40]],steps:"Portion roasted chana into a small container. No cooking needed.",protein:"high"},
 {id:22,name:"Banana & peanuts",slot:"snack",diet:"vegan",cost:12,kcal:210,p:5,c:31,f:9,time:1,emoji:"🍌",ingredients:[["banana",1],["peanuts",15]],steps:"Eat one banana with a small handful of peanuts.",protein:"medium"},
 {id:23,name:"Boiled eggs",slot:"snack",diet:"nonveg",cost:14,kcal:155,p:13,c:1,f:11,time:10,emoji:"🥚",ingredients:[["eggs",2]],steps:"Boil eggs for 8–10 minutes. Season with salt and pepper.",protein:"high"},
 {id:24,name:"Buttermilk & chana",slot:"snack",diet:"vegetarian",cost:15,kcal:170,p:8,c:25,f:4,time:2,emoji:"🥛",ingredients:[["buttermilk",200],["roasted chana",25]],steps:"Serve chilled buttermilk with roasted chana.",protein:"medium"},
 {id:25,name:"Sprout sundal",slot:"snack",diet:"vegan",cost:16,kcal:190,p:12,c:29,f:4,time:8,emoji:"🥗",ingredients:[["sprouts",100],["peanuts",8]],steps:"Steam sprouts and toss with mustard, curry leaves and peanuts.",protein:"high"},
 {id:26,name:"Curd with roasted seeds",slot:"snack",diet:"vegetarian",cost:13,kcal:150,p:8,c:13,f:7,time:2,emoji:"🥣",ingredients:[["curd",150],["peanuts",8]],steps:"Top a bowl of curd with roasted peanuts and a pinch of salt.",protein:"medium"},
 {id:27,name:"Sattu drink",slot:"snack",diet:"vegan",cost:12,kcal:190,p:10,c:27,f:4,time:3,emoji:"🥤",ingredients:[["sattu",35],["lemon",0.5]],steps:"Whisk sattu with cold water, lemon, salt and roasted cumin.",protein:"high"},
 {id:28,name:"Peanut chikki",slot:"snack",diet:"vegan",cost:10,kcal:170,p:5,c:20,f:9,time:1,emoji:"🍬",ingredients:[["peanuts",20],["jaggery",12]],steps:"Have a small portion of peanut-jaggery chikki.",protein:"medium"},
 {id:29,name:"Milk & banana",slot:"snack",diet:"vegetarian",cost:15,kcal:210,p:8,c:34,f:5,time:2,emoji:"🥛",ingredients:[["milk",200],["banana",1]],steps:"Blend or serve milk alongside a banana.",protein:"medium"},
 {id:30,name:"Boiled sweet potato",slot:"snack",diet:"vegan",cost:12,kcal:160,p:3,c:37,f:0,time:12,emoji:"🍠",ingredients:[["sweet potato",150]],steps:"Boil sweet potato until tender. Add lemon and chaat masala.",protein:"low"},
 {id:31,name:"Dal tadka & roti",slot:"dinner",diet:"vegan",cost:30,kcal:460,p:19,c:70,f:10,time:18,emoji:"🍛",ingredients:[["toor dal",50],["roti",2],["onion",0.3],["tomato",0.3]],steps:"Cook dal until soft and add a quick cumin-garlic tadka. Serve with rotis.",protein:"high"},
 {id:32,name:"Soya keema roti",slot:"dinner",diet:"vegan",cost:36,kcal:470,p:30,c:55,f:9,time:18,emoji:"🥘",ingredients:[["soya chunks",40],["roti",2],["onion",0.3],["tomato",0.3]],steps:"Pulse boiled soya into a mince. Cook with spices and serve with rotis.",protein:"high"},
 {id:33,name:"Vegetable dalia",slot:"dinner",diet:"vegan",cost:24,kcal:380,p:13,c:68,f:6,time:15,emoji:"🥣",ingredients:[["dalia",65],["moong dal",20],["mixed vegetables",50]],steps:"Pressure cook dalia, dal and vegetables with mild spices.",protein:"medium"},
 {id:34,name:"Curd rice & peanuts",slot:"dinner",diet:"vegetarian",cost:25,kcal:390,p:12,c:63,f:9,time:8,emoji:"🍚",ingredients:[["rice",65],["curd",120],["peanuts",10]],steps:"Mix cooked cooled rice with curd. Temper mustard and peanuts and mix in.",protein:"medium"},
 {id:35,name:"Egg fried rice",slot:"dinner",diet:"nonveg",cost:38,kcal:480,p:21,c:66,f:13,time:12,emoji:"🍳",ingredients:[["rice",70],["eggs",1],["mixed vegetables",50]],steps:"Stir-fry vegetables, add egg and cooked rice. Season lightly.",protein:"high"},
 {id:36,name:"Chole & rice",slot:"dinner",diet:"vegan",cost:32,kcal:490,p:18,c:83,f:8,time:20,emoji:"🍲",ingredients:[["chickpeas",55],["rice",60],["tomato",0.3]],steps:"Simmer cooked chickpeas in tomato masala and serve with rice.",protein:"high"},
 {id:37,name:"Masoor dal & rice",slot:"dinner",diet:"vegan",cost:27,kcal:440,p:19,c:77,f:5,time:15,emoji:"🍚",ingredients:[["masoor dal",50],["rice",60],["tomato",0.3]],steps:"Cook masoor dal with tomato and turmeric. Serve with rice.",protein:"high"},
 {id:38,name:"Paneer rice bowl",slot:"dinner",diet:"vegetarian",cost:48,kcal:500,p:25,c:61,f:16,time:12,emoji:"🧀",ingredients:[["paneer",60],["rice",60],["mixed vegetables",50]],steps:"Pan-sear paneer and vegetables. Serve over rice with spices.",protein:"high"},
 {id:39,name:"Vegetable khichdi & curd",slot:"dinner",diet:"vegetarian",cost:32,kcal:440,p:17,c:72,f:8,time:18,emoji:"🥘",ingredients:[["rice",45],["moong dal",40],["mixed vegetables",40],["curd",70]],steps:"Cook rice, dal and vegetables together. Serve with a little curd.",protein:"high"},
 {id:40,name:"Chicken rice bowl",slot:"dinner",diet:"nonveg",cost:55,kcal:520,p:35,c:61,f:11,time:22,emoji:"🍗",ingredients:[["chicken",90],["rice",65],["onion",0.3]],steps:"Cook small chicken pieces thoroughly with onion and spices. Serve with rice.",protein:"high"},
 {id:41,name:"Tomato dal & rice",slot:"lunch",diet:"vegan",cost:28,kcal:455,p:18,c:78,f:6,time:16,emoji:"🍅",ingredients:[["toor dal",45],["rice",65],["tomato",1]],steps:"Cook dal with tomato, chilli and turmeric. Serve with rice.",protein:"high"},
 {id:42,name:"Kala chana salad",slot:"lunch",diet:"vegan",cost:29,kcal:390,p:18,c:62,f:7,time:8,emoji:"🥗",ingredients:[["black chana",65],["onion",0.3],["tomato",0.3],["lemon",0.5]],steps:"Mix boiled kala chana with chopped vegetables, lemon and spices.",protein:"high"},
 {id:43,name:"Aloo matar & roti",slot:"lunch",diet:"vegan",cost:27,kcal:460,p:12,c:76,f:10,time:16,emoji:"🥔",ingredients:[["potato",100],["peas",35],["roti",2]],steps:"Cook potato and peas in a simple masala. Serve with rotis.",protein:"medium"},
 {id:44,name:"Masala omelette & toast",slot:"breakfast",diet:"nonveg",cost:27,kcal:340,p:19,c:32,f:14,time:8,emoji:"🍳",ingredients:[["eggs",2],["bread",2],["onion",0.2]],steps:"Beat eggs with onion and spices. Cook as an omelette and serve with toast.",protein:"high"},
 {id:45,name:"Ragi porridge",slot:"breakfast",diet:"vegan",cost:17,kcal:290,p:7,c:58,f:4,time:7,emoji:"🥣",ingredients:[["ragi flour",45],["jaggery",10],["banana",0.5]],steps:"Whisk ragi flour into water and cook until thick. Sweeten lightly and add banana.",protein:"low"},
 {id:46,name:"Dosa & peanut chutney",slot:"breakfast",diet:"vegan",cost:23,kcal:350,p:10,c:55,f:10,time:10,emoji:"🥞",ingredients:[["dosa",2],["peanuts",15]],steps:"Cook dosa batter on a hot pan. Serve with quick peanut chutney.",protein:"medium"},
 {id:47,name:"Soya pulao",slot:"lunch",diet:"vegan",cost:35,kcal:490,p:25,c:74,f:8,time:18,emoji:"🍚",ingredients:[["soya chunks",35],["rice",65],["mixed vegetables",40]],steps:"Cook soaked soya and vegetables with rice and whole spices.",protein:"high"},
 {id:48,name:"Peanut chaat",slot:"snack",diet:"vegan",cost:13,kcal:200,p:8,c:18,f:11,time:4,emoji:"🥜",ingredients:[["peanuts",25],["onion",0.2],["tomato",0.2],["lemon",0.3]],steps:"Toss roasted peanuts with onion, tomato, lemon and chaat masala.",protein:"medium"},
 {id:49,name:"Lemon dalia",slot:"dinner",diet:"vegan",cost:22,kcal:360,p:11,c:65,f:6,time:15,emoji:"🍋",ingredients:[["dalia",60],["peas",20],["lemon",0.5]],steps:"Cook dalia with peas until soft. Finish with lemon juice.",protein:"medium"},
 {id:50,name:"Palak dal & roti",slot:"dinner",diet:"vegan",cost:31,kcal:430,p:20,c:66,f:8,time:18,emoji:"🥬",ingredients:[["moong dal",45],["spinach",50],["roti",2]],steps:"Cook dal with chopped spinach and spices. Serve with rotis.",protein:"high"}
];
const slotNames={breakfast:"BREAKFAST",lunch:"LUNCH",snack:"EVENING SNACK",dinner:"DINNER"};
let currentPlan=[], macroChart=null;
const money=n=>"₹"+Math.round(n);
const escapeHTML=value=>String(value).replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;", "'":"&#39;"}[ch]));
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
function getProfile(){return {budget:Math.max(40,Number($("budget").value)||120),diet:$("diet").value,goal:$("goal").value,priceIndex:Number($("priceIndex")?.value||100)}}
function eligible(r,diet){return diet==="all" || (diet==="vegetarian" && r.diet!=="nonveg") || (diet==="nonveg" && r.diet!=="vegan") || (diet==="vegan" && r.diet==="vegan")}
function targetProtein(goal){return goal==="muscle"?100:goal==="loss"?85:75}
function targetCalories(goal){return goal==="muscle"?2100:goal==="loss"?1800:2000}
function summarize(plan){return plan.reduce((a,r)=>({cost:a.cost+r.cost,kcal:a.kcal+r.kcal,p:a.p+r.p,c:a.c+r.c,f:a.f+r.f}),{cost:0,kcal:0,p:0,c:0,f:0})}
function optimizeDay(profile, previousIds=[]){
 const slots=["breakfast","lunch","snack","dinner"], pools=slots.map(slot=>recipes.filter(r=>r.slot===slot&&eligible(r,profile.diet)));
 if(pools.some(pool=>!pool.length))return null;
 const proteinGoal=targetProtein(profile.goal),calorieGoal=targetCalories(profile.goal);let best=null,bestScore=-Infinity;
 pools.forEach((pool,i)=>{pools[i]=pool.map(r=>({...r,cost:Math.ceil(r.cost*(profile.priceIndex||100)/100)}));});
 // Exhaustive four-slot search: every candidate is checked against the hard budget cap.
 function visit(index,chosen,cost,kcal,protein,carbs,fat){
  if(cost>profile.budget)return;
  if(index===slots.length){
   const calorieFit=Math.max(0,100-(Math.abs(kcal-calorieGoal)/calorieGoal)*100);
   const proteinFit=Math.min(1.15,protein/proteinGoal)*100;
   const efficiency=(protein/Math.max(cost,1))*18;
   const spendFit=(cost/profile.budget)*7;
   const ids=chosen.map(r=>r.id),uniqueIngredients=new Set(chosen.flatMap(r=>r.ingredients.map(x=>x[0]))).size;
   const repeatPenalty=ids.reduce((n,id)=>n+(previousIds.includes(id)?1000:0),0);
   const score=calorieFit*.48+proteinFit*.34+Math.min(18,efficiency)+spendFit+uniqueIngredients*.35-repeatPenalty;
   if(score>bestScore){bestScore=score;best=chosen.map(r=>({...r}));}return;
  }
  for(const r of pools[index])visit(index+1,[...chosen,r],cost+r.cost,kcal+r.kcal,protein+r.p,carbs+r.c,fat+r.f);
 }
 visit(0,[],0,0,0,0,0);return best;
}
function generatePlan(){
 const profile=getProfile();
 if(!Number.isFinite(profile.budget)||profile.budget<40){toast("Please enter a daily budget of at least ₹40.");return;}
 const plan=optimizeDay(profile);
 if(!plan){toast("No four-meal combination fits this budget. Increase the daily budget and try again.");return;}
 currentPlan=plan;weeklyPlan=[];renderPlan();renderNutrition();renderGroceries();renderWeek();saveState();toast("A budget-checked meal plan is ready!");
}
function ingredientBreakdown(recipe){
 const weighted=recipe.ingredients.map(([name,qty])=>({name,qty,weight:Math.max(.1,(unitCost[name]||.1)*qty)}));
 const totalWeight=weighted.reduce((sum,item)=>sum+item.weight,0);
 return weighted.map(item=>({...item,cost:recipe.cost*item.weight/totalWeight}));
}
function renderPlan(){
 const total=summarize(currentPlan).cost,budget=getProfile().budget;
 $("mealCards").innerHTML=currentPlan.map((r,i)=>{const details=ingredientBreakdown(r);return `<article class="meal-card"><div class="meal-emoji">${r.emoji}</div><div><div class="meal-type">${slotNames[r.slot]} · ${r.time} MIN</div><div class="meal-name">${r.name}</div><div class="meal-meta">${r.kcal} kcal · ${r.p}g protein · ${r.diet==="nonveg"?"Non-veg":r.diet==="vegan"?"Vegan":"Vegetarian"}</div><button class="details-toggle" data-details="${i}" aria-expanded="false">View ingredient costs & cooking steps +</button></div><div class="meal-cost">${money(r.cost)}<small>per serving</small></div><button class="swap-btn" data-swap="${i}">⇄ Swap</button><div class="recipe-details" id="recipeDetails${i}" hidden><h5>INGREDIENT COST BREAKDOWN · ESTIMATED</h5><div class="ingredient-breakdown">${details.map(x=>`<span>${x.name} (${x.qty}) · ${money(x.cost)}</span>`).join("")}</div><h5>HOSTEL-FRIENDLY METHOD</h5><p>${r.steps}</p></div></article>`}).join("");
 $("totalCost").textContent=money(total);$("remainingCost").textContent=money(Math.max(0,budget-total));$("totalStatus").textContent=total<=budget?"✓ Within budget":"Budget exceeded";
 $("spendValue").innerHTML=`${money(total)} <small>/ ${money(budget)}</small>`;$("spendProgress").style.width=Math.min(100,total/budget*100)+"%";
 $("budgetStatus").textContent=total<=budget?`${Math.round((budget-total)/budget*100)}% of budget left`:"Budget exceeded";
 $("mealCount").innerHTML=`${currentPlan.length} <small>/ 4</small>`;
 $("mealCards").querySelectorAll("[data-swap]").forEach(btn=>btn.addEventListener("click",()=>swapMeal(Number(btn.dataset.swap))));
 $("mealCards").querySelectorAll("[data-details]").forEach(btn=>btn.addEventListener("click",()=>{const panel=$("recipeDetails"+btn.dataset.details),open=panel.hidden;panel.hidden=!open;btn.textContent=open?"Hide recipe details −":"View ingredient costs & cooking steps +";btn.setAttribute("aria-expanded",String(open));}));
}
function swapMeal(index){
 const old=currentPlan[index],profile=getProfile(),other=currentPlan.filter((_,i)=>i!==index),otherCost=summarize(other).cost;
 const alternatives=recipes.filter(r=>r.slot===old.slot&&eligible(r,profile.diet)&&r.id!==old.id)
  .map(r=>({...r,cost:Math.ceil(r.cost*(profile.priceIndex||100)/100)})).filter(r=>otherCost+r.cost<=profile.budget).map(r=>({r,score:100-Math.abs(r.p-old.p)*2-Math.abs(r.kcal-old.kcal)/8-Math.abs(r.cost-old.cost)*.8}))
  .sort((a,b)=>b.score-a.score);
 if(!alternatives.length){toast("No nutritionally similar alternative fits the remaining budget.");return;}
 currentPlan[index]={...alternatives[0].r};renderPlan();renderNutrition();renderGroceries();saveState();toast("Meal swapped. Daily total remains within budget.");
}
function renderNutrition(){
 const total=currentPlan.reduce((s,r)=>({k:s.k+r.kcal,p:s.p+r.p,c:s.c+r.c,f:s.f+r.f}),{k:0,p:0,c:0,f:0}),target=targetProtein(getProfile().goal),calTarget=targetCalories(getProfile().goal);
 $("calValue").innerHTML=`${total.k} <small>kcal</small>`;$("proteinValue").innerHTML=`${total.p} <small>g</small>`;$("proteinFoot").textContent=`${Math.round(total.p/target*100)}% of ${target}g target`;
 $("chartCalories").textContent=total.k.toLocaleString();$("chartProtein").textContent=total.p+"g";$("chartCarbs").textContent=total.c+"g";$("chartFat").textContent=total.f+"g";
 $("proteinTarget").textContent=target+"g";$("proteinTargetBar").style.width=Math.min(100,total.p/target*100)+"%";
 $("targetMessage").textContent=total.p>=target?"Protein target reached (illustrative).":`${Math.max(0,target-total.p)}g below the illustrative protein target.`;
 $("calorieTarget").textContent=calTarget.toLocaleString()+" kcal";$("carbTarget").textContent=Math.round(calTarget*.5/4)+"g";$("fatTarget").textContent=Math.round(calTarget*.25/9)+"g";$("calorieMessage").textContent=`Energy: ${total.k} / ${calTarget} kcal · ${Math.round(total.k/calTarget*100)}% of target. Adjust portions with a dietitian if needed.`;
 if(window.Chart){if(macroChart)macroChart.destroy();macroChart=new Chart($("macroChart"),{type:"doughnut",data:{labels:["Protein","Carbs","Fats"],datasets:[{data:[total.p*4,total.c*4,total.f*9],backgroundColor:["#b9f36a","#6eafed","#ffbd69"],borderWidth:0,hoverOffset:5}]},options:{responsive:true,maintainAspectRatio:false,cutout:"76%",plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>`${c.label}: ${Math.round(c.raw)} kcal`}}}}})}
}
const unitCost={"rice":0.05,"oats":0.12,"banana":5,"milk":0.06,"eggs":7,"roti":5,"onion":2,"tomato":2,"moong dal":0.12,"peanuts":0.18,"bread":3,"peanut butter":0.25,"poha":0.06,"potato":2,"sprouts":0.1,"lemon":2,"idli":6,"sambar":0.05,"besan":0.09,"curd":0.07,"rava":0.06,"peas":0.12,"toor dal":0.13,"soya chunks":0.16,"chickpeas":0.12,"rajma":0.15,"paneer":0.35,"mixed vegetables":0.1,"fish":0.45,"roasted chana":0.1,"buttermilk":0.04,"sattu":0.12,"jaggery":0.08,"sweet potato":0.05,"dalia":0.07,"masoor dal":0.13,"chicken":0.4,"black chana":0.12,"ragi flour":0.08,"dosa":8,"spinach":0.1,"carrot":2};
function renderGroceries(){
 if(!currentPlan.length)return;
 const totals={};const sourceDays=weeklyPlan.length?weeklyPlan.map(d=>d.meals):[...Array(7)].map(()=>currentPlan);sourceDays.forEach(day=>day.forEach(r=>r.ingredients.forEach(([name,qty])=>{totals[name]=(totals[name]||0)+qty})));
 const groups={Staples:["rice","roti","bread","oats","poha","rava","dalia","dosa","ragi flour"],Protein:["eggs","moong dal","toor dal","masoor dal","soya chunks","chickpeas","rajma","black chana","paneer","chicken","fish","sprouts","roasted chana","peanuts"],Fresh:["banana","onion","tomato","potato","peas","mixed vegetables","carrot","spinach","lemon"],Dairy:["milk","curd","buttermilk","sambar"],Other:["peanut butter","jaggery","sattu","sweet potato"]};
 let bill=0,html="";
 Object.entries(groups).forEach(([group,names])=>{let items=names.filter(n=>totals[n]);if(!items.length)return;html+=`<div class="grocery-category"><h4>${group}</h4>${items.map(n=>{let q=totals[n],cost=(unitCost[n]||.1)*q*(getProfile().priceIndex||100)/100;bill+=cost;return `<div class="grocery-item"><span>${n} <small>× ${Number(q.toFixed(1))}</small></span><b>${money(cost)}</b></div>`}).join("")}</div>`});
 $("groceryList").innerHTML=html;$("weeklyTotal").textContent=money(bill);
}
let weeklyPlan=[];
function generateWeek(){
 if(!currentPlan.length){toast("Generate your daily plan first.");return;}
 const profile=getProfile(),days=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],built=[];let recent=[];
 for(let i=0;i<7;i++){
  let day=optimizeDay(profile,recent);
  if(!day)day=optimizeDay(profile,recent.slice(-8));
  if(!day)day=optimizeDay(profile,[]);
  if(!day){toast("Could not build all 7 days under this budget. Increase the daily budget.");return;}
  built.push({day:days[i],meals:day});recent.push(...day.map(r=>r.id));
 }
 weeklyPlan=built;renderWeek();renderGroceries();saveState();toast("Your 7-day plan is ready. Each day respects the selected budget.");
}
function renderWeek(){
 const host=$("weeklyGrid"),summary=$("weeklySummary");if(!host||!summary)return;
 if(!weeklyPlan.length){host.innerHTML="";summary.textContent="Generate your daily plan first, then build a complete week.";return;}
 const spend=weeklyPlan.reduce((n,d)=>n+summarize(d.meals).cost,0),avg=spend/7;
 summary.textContent=`7 days · ${money(spend)} estimated total · ${money(avg)} average per day · Daily cap ${money(getProfile().budget)}.`;
 host.innerHTML=weeklyPlan.map(d=>{const t=summarize(d.meals);return `<article class="week-day"><div class="week-day-head"><b>${d.day}</b><span>${money(t.cost)} / ${money(getProfile().budget)}</span></div>${d.meals.map(r=>`<div class="week-meal"><span>${r.emoji} ${r.name}</span><small>${money(r.cost)}</small></div>`).join("")}<div class="week-day-foot"><span>${t.kcal} kcal · ${t.p}g protein</span><b>${t.cost<=getProfile().budget?"Within cap":"Over cap"}</b></div></article>`}).join("");
}
function exportWeek(){if(!weeklyPlan.length){toast("Generate your 7-day plan first.");return;}window.print();}
function saveState(){localStorage.setItem("platepilot-state",JSON.stringify({profile:getProfile(),plan:currentPlan,week:weeklyPlan}))}
function loadState(){
 try{const s=JSON.parse(localStorage.getItem("platepilot-state"));if(s?.profile){$("budget").value=s.profile.budget;$("diet").value=s.profile.diet;$("goal").value=s.profile.goal;if(s.profile.priceIndex){$("priceIndex").value=s.profile.priceIndex;$("priceIndexLabel").textContent=s.profile.priceIndex+"%"}}if(s?.plan?.length){currentPlan=s.plan;renderPlan();renderNutrition();if(s?.week?.length)weeklyPlan=s.week;renderWeek();renderGroceries()}}catch(e){console.warn("Saved plan could not be loaded",e)}
}
function pantrySearch(){
 const words=$("pantryInput").value.toLowerCase().split(",").map(s=>s.trim()).filter(Boolean);if(!words.length){toast("Enter at least one ingredient.");return}
 const matches=recipes.map(r=>({...r,match:r.ingredients.filter(([n])=>words.some(w=>n.includes(w)||w.includes(n))).length})).filter(r=>r.match>0).sort((a,b)=>b.match-a.match||a.cost-b.cost).slice(0,5);
 $("pantryResults").innerHTML=matches.length?matches.map(r=>`<span class="result-chip">${r.emoji} ${r.name} <b>${money(r.cost)}</b> · ${r.match} match</span>`).join(""):"<small class='muted'>No close match found. Try staple names like rice, dal, oats or banana.</small>";
}
function messAnalyze(){
 const selected=[...document.querySelectorAll(".mess-options input:checked")].map(x=>x.value),map={rice:["rice","Carbohydrate base"],dal:["dal","Protein + fibre"],roti:["roti","Whole-grain energy"],sabzi:["sabzi","Micronutrients"],curd:["curd","Calcium + protein"],egg:["egg","High-quality protein"]};
 if(!selected.length){$("messResults").innerHTML="<small class='muted'>Select at least one mess item.</small>";return}
 let picks=selected.map(k=>map[k]);let missing=selected.includes("egg")||selected.includes("dal")?"You have a protein source.":"Add roasted chana (about ₹10) or sattu (about ₹12) for extra protein.";
 if(!selected.includes("sabzi"))missing+=" Add a seasonal fruit or vegetable when possible.";
 $("messResults").innerHTML=`<div>${picks.map(p=>`<span class="result-chip">✓ ${p[0]} <b>${p[1]}</b></span>`).join("")}</div><p class="muted" style="margin:10px 0 0">${missing}</p>`;
}
function communityRender(){
 let items=[];try{items=JSON.parse(localStorage.getItem("platepilot-community")||"[]")}catch(e){}
 const defaults=[{name:"Masala peanut chaat",cost:13,protein:8,desc:"Roasted peanuts, onion, tomato, lemon and chaat masala. Toss and serve.",tag:"NO-COOK HACK"},{name:"Quick sattu cooler",cost:12,protein:10,desc:"Whisk sattu with water, lemon, cumin and a pinch of salt.",tag:"3-MINUTE RECIPE"},{name:"Sprouts sundal",cost:16,protein:12,desc:"Steam sprouts and toss with mustard, curry leaves and peanuts.",tag:"PROTEIN PICK"}];
 const all=[...items,...defaults];$("communityList").innerHTML=all.slice(0,6).map(r=>`<article class="community-card"><div class="tag">${r.tag||"STUDENT SUBMISSION"}</div><h4>${escapeHTML(r.name)}</h4><p>${escapeHTML(r.desc)}</p><div class="community-meta"><span>${money(r.cost)} / serve</span><span>${r.protein}g protein</span></div></article>`).join("");
}
function copyGroceries(){
 if(!currentPlan.length){toast("Generate a plan first.");return}
 const map={};const sourceDays=weeklyPlan.length?weeklyPlan.map(d=>d.meals):[...Array(7)].map(()=>currentPlan);sourceDays.forEach(day=>day.forEach(r=>r.ingredients.forEach(([n,q])=>map[n]=(map[n]||0)+q)));
 const text=Object.entries(map).map(([n,q])=>`${n}: ${q.toFixed(1)} units`).join("\n");
 navigator.clipboard?.writeText("PLATEPILOT WEEKLY SHOPPING LIST\n"+text).then(()=>toast("Grocery list copied!")).catch(()=>toast("Clipboard unavailable in this browser."));
}
$("generateBtn").addEventListener("click",generatePlan);$("generateWeek").addEventListener("click",generateWeek);$("exportWeek").addEventListener("click",exportWeek);$("pantryBtn").addEventListener("click",pantrySearch);$("messBtn").addEventListener("click",messAnalyze);$("copyGroceries").addEventListener("click",copyGroceries);
$("savePlan").addEventListener("click",()=>{if(!currentPlan.length){toast("Generate a plan first.");return}saveState();toast("Plan saved in this browser.")});
$("printTop").addEventListener("click",()=>window.print());
$("addRecipeBtn").addEventListener("click",()=>$("recipeDialog").showModal());
$("recipeForm").addEventListener("submit",e=>{e.preventDefault();const item={name:$("communityName").value.trim(),cost:Number($("communityCost").value),protein:Number($("communityProtein").value),desc:$("communityDescription").value.trim(),tag:"STUDENT SUBMISSION"};if(!item.name||!item.desc||item.cost<1||item.protein<0)return;let list=JSON.parse(localStorage.getItem("platepilot-community")||"[]");list.unshift(item);localStorage.setItem("platepilot-community",JSON.stringify(list));communityRender();$("recipeDialog").close();$("recipeForm").reset();toast("Your recipe was shared locally!")});
$("priceIndex").addEventListener("input",e=>{$("priceIndexLabel").textContent=e.target.value+"%";});
$("todayLabel").textContent=new Date().toLocaleDateString("en-IN",{weekday:"short",day:"2-digit",month:"short"}).toUpperCase();
document.querySelectorAll(".nav-link").forEach(a=>a.addEventListener("click",()=>{document.querySelectorAll(".nav-link").forEach(n=>n.classList.remove("active"));a.classList.add("active")}));
communityRender();loadState();
