/**
 * PlatePilot Chart.js Integration
 * Macronutrient doughnut charts and interactive RDA target visualizers.
 */

const ChartsManager = {
  chartInstance: null,

  init() {
    this.createDoughnutChart([22, 53, 25]); // Default sample macro split
  },

  createDoughnutChart(percentages = [25, 55, 20]) {
    const canvas = document.getElementById('macroDoughnutChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (this.chartInstance) {
      this.chartInstance.destroy();
    }

    this.chartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Protein', 'Carbs', 'Healthy Fats'],
        datasets: [{
          data: percentages,
          backgroundColor: [
            '#f43f5e', // Protein (Rose red)
            '#f59e0b', // Carbs (Amber)
            '#10b981'  // Fats (Emerald green)
          ],
          borderColor: 'transparent',
          borderWidth: 0,
          hoverOffset: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '72%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 12,
              padding: 12,
              color: '#94a3b8',
              font: {
                family: 'Plus Jakarta Sans',
                size: 11,
                weight: '600'
              }
            }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return ` ${context.label}: ${context.raw}% of daily calories`;
              }
            }
          }
        }
      }
    });
  },

  updateVisualizer(totals, macroPercentages, rdaTargets) {
    if (!totals) return;

    // 1. Update Metrics Row Numbers
    const elCost = document.getElementById('metricCost');
    const elCap = document.getElementById('metricBudgetCap');
    const elCal = document.getElementById('metricCalories');
    const elCalTarget = document.getElementById('metricCalTarget');
    const elProtein = document.getElementById('metricProtein');
    const elProteinRda = document.getElementById('metricProteinRda');
    const elRatio = document.getElementById('metricEfficiency');

    if (elCost) elCost.textContent = `₹${totals.cost}`;
    if (elCap) {
      const budget = AppState.dailyBudget;
      const pct = Math.round((totals.cost / budget) * 100);
      elCap.textContent = `Cap: ₹${budget}.0 (${pct}% utilized)`;
    }
    if (elCal) elCal.textContent = `${totals.calories} kcal`;
    if (elCalTarget && rdaTargets) elCalTarget.textContent = `RDA Goal: ~${rdaTargets.targetCalories} kcal`;
    if (elProtein) elProtein.textContent = `${totals.protein}g`;
    if (elProteinRda && rdaTargets) elProteinRda.textContent = `Target: ${rdaTargets.targetProtein}g (RDA)`;
    if (elRatio) {
      const ratio = totals.cost > 0 ? (totals.protein / totals.cost).toFixed(2) : 0;
      elRatio.textContent = `${ratio}g / ₹`;
    }

    // 2. Update Chart.js Doughnut Data
    if (macroPercentages) {
      const p = macroPercentages.proteinPct || 25;
      const c = macroPercentages.carbsPct || 55;
      const f = macroPercentages.fatsPct || 20;

      if (this.chartInstance) {
        this.chartInstance.data.datasets[0].data = [p, c, f];
        this.chartInstance.update();
      } else {
        this.createDoughnutChart([p, c, f]);
      }
    }

    // 3. Update RDA Progress Bars
    if (rdaTargets) {
      const targetProt = rdaTargets.targetProtein || 90;
      const targetCal = rdaTargets.targetCalories || 2200;
      const targetCarbs = rdaTargets.targetCarbs || 275;
      const targetFats = rdaTargets.targetFats || 60;

      const protPct = Math.min(100, Math.round((totals.protein / targetProt) * 100));
      const calPct = Math.min(100, Math.round((totals.calories / targetCal) * 100));
      const carbPct = Math.min(100, Math.round((totals.carbs / targetCarbs) * 100));
      const fatPct = Math.min(100, Math.round((totals.fats / targetFats) * 100));

      document.getElementById('rdaProteinTxt').textContent = `${totals.protein}g / ${targetProt}g (${protPct}%)`;
      document.getElementById('rdaProteinBar').style.width = `${protPct}%`;

      document.getElementById('rdaCaloriesTxt').textContent = `${totals.calories} / ${targetCal} kcal (${calPct}%)`;
      document.getElementById('rdaCalorieBar').style.width = `${calPct}%`;

      document.getElementById('rdaCarbsTxt').textContent = `${totals.carbs}g / ${targetCarbs}g (${carbPct}%)`;
      document.getElementById('rdaCarbBar').style.width = `${carbPct}%`;

      document.getElementById('rdaFatsTxt').textContent = `${totals.fats}g / ${targetFats}g (${fatPct}%)`;
      document.getElementById('rdaFatBar').style.width = `${fatPct}%`;
    }
  }
};
