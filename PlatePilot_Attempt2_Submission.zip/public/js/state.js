/**
 * PlatePilot Application State Store
 * Manages reactive UI state, user profile parameters, active plan,
 * localStorage persistence, and event notifications.
 */

const AppState = {
  // Profiler defaults
  dailyBudget: 120,
  dietPreference: 'non-veg',
  fitnessGoal: 'Muscle Gain',
  priceMultiplier: 1.0,
  pantryItemsSelected: [],

  // Active generated meal plan
  currentPlan: null,

  // RDA target values
  rdaTargets: {
    targetCalories: 2200,
    targetProtein: 95,
    targetCarbs: 275,
    targetFats: 60
  },

  // Grocery state
  groceryList: null,
  groceryDays: 7,

  // Catalog & Community cache
  catalogRecipes: [],
  communityRecipes: [],
  hostelMessSchedule: [],

  init() {
    this.loadFromStorage();
  },

  setPlan(plan) {
    this.currentPlan = plan;
    if (plan.meta && plan.meta.rdaTargets) {
      this.rdaTargets = plan.meta.rdaTargets;
    }
    this.saveToStorage();
  },

  setPriceMultiplier(mult) {
    this.priceMultiplier = mult;
    this.saveToStorage();
  },

  saveToStorage() {
    try {
      const data = {
        dailyBudget: this.dailyBudget,
        dietPreference: this.dietPreference,
        fitnessGoal: this.fitnessGoal,
        priceMultiplier: this.priceMultiplier,
        currentPlan: this.currentPlan
      };
      localStorage.setItem('platepilot_state', JSON.stringify(data));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  },

  loadFromStorage() {
    try {
      const saved = localStorage.getItem('platepilot_state');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.dailyBudget) this.dailyBudget = parsed.dailyBudget;
        if (parsed.dietPreference) this.dietPreference = parsed.dietPreference;
        if (parsed.fitnessGoal) this.fitnessGoal = parsed.fitnessGoal;
        if (parsed.priceMultiplier) this.priceMultiplier = parsed.priceMultiplier;
        if (parsed.currentPlan) this.currentPlan = parsed.currentPlan;
      }
    } catch (e) {
      console.warn('LocalStorage load failed:', e);
    }
  }
};
