/**
 * PlatePilot API Client
 * Centralized fetch wrapper with robust error interception, network resilience,
 * and structured JSON responses.
 */

const API = {
  baseUrl: '/api',

  async request(endpoint, options = {}) {
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    };

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, config);
      const data = await response.json();

      if (!response.ok) {
        const errorMsg = data.error || (data.details && data.details.join('; ')) || `Request failed with status ${response.status}`;
        throw new Error(errorMsg);
      }

      return data;
    } catch (err) {
      console.error(`[API Error] ${endpoint}:`, err);
      throw err;
    }
  },

  // Profiler & RDA
  async getRDAGoals(fitnessGoal, weightKg = 65) {
    return this.request(`/budget/rda?fitnessGoal=${encodeURIComponent(fitnessGoal)}&weightKg=${weightKg}`);
  },

  async saveBudgetProfile(profileData) {
    return this.request('/budget/profile', {
      method: 'POST',
      body: JSON.stringify(profileData)
    });
  },

  // Optimizer & Knapsack Planning
  async optimizeMealPlan(params) {
    return this.request('/optimize', {
      method: 'POST',
      body: JSON.stringify(params)
    });
  },

  // Meal Swap Engine
  async getSwapOptions(params) {
    return this.request('/swap/options', {
      method: 'POST',
      body: JSON.stringify(params)
    });
  },

  async executeSwap(params) {
    return this.request('/swap/execute', {
      method: 'POST',
      body: JSON.stringify(params)
    });
  },

  // Smart Grocery List
  async getGroceryList(meals, days = 7, priceMultiplier = 1.0) {
    return this.request('/grocery-list', {
      method: 'POST',
      body: JSON.stringify({ meals, days, priceMultiplier })
    });
  },

  // Plan Persistence
  async savePlan(planName, plan) {
    return this.request('/plans/save', {
      method: 'POST',
      body: JSON.stringify({ planName, plan })
    });
  },

  async getSavedPlans() {
    return this.request('/plans/saved');
  },

  // Recipe Catalog
  async getRecipes(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/recipes${query ? '?' + query : ''}`);
  },

  async getRecipeById(id) {
    return this.request(`/recipes/${id}`);
  },

  // Stretch Features
  async getHostelMessGuide() {
    return this.request('/hostel-mess');
  },

  async getPantryItems() {
    return this.request('/pantry/items');
  },

  async optimizePantry(pantryItemIds, dietPreference) {
    return this.request('/pantry/optimize', {
      method: 'POST',
      body: JSON.stringify({ pantryItemIds, dietPreference })
    });
  },

  async getCommunityRecipes() {
    return this.request('/community-recipes');
  },

  async submitCommunityRecipe(recipeData) {
    return this.request('/community-recipes', {
      method: 'POST',
      body: JSON.stringify(recipeData)
    });
  },

  async upvoteCommunityRecipe(id) {
    return this.request(`/community-recipes/${id}/upvote`, {
      method: 'POST'
    });
  }
};
