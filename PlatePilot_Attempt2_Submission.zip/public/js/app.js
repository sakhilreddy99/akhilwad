/**
 * PlatePilot Main Controller & App Coordinator
 * Coordinates state, event listeners, API requests, and view updates.
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Initialize State & Charts
  AppState.init();
  ChartsManager.init();

  // Setup Event Listeners
  setupNavigationTabs();
  setupProfilerForm();
  setupRegionalPriceSlider();
  setupThemeToggle();
  setupModals();
  setupDemoButton();
  setupPrintCheatSheet();
  setupGroceryDurationSelector();
  setupCommunityFeatures();
  setupPantryOptimizer();
  setupCatalogFilters();

  // Initial Load: Run demo case or restore previous plan
  try {
    await loadInitialPlan();
    await loadHostelMessGuide();
    await loadPantryInventory();
    await loadCommunityFeed();
    await loadRecipeCatalog();
  } catch (err) {
    console.error('Initial bootstrap error:', err);
    UI.showToast('Initialized PlatePilot with local defaults.', 'info');
  }
});

/**
 * Tab Navigation Controller
 */
function setupNavigationTabs() {
  const tabs = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.tab-panel');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetId = tab.getAttribute('data-tab');

      tabs.forEach(t => t.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));

      tab.classList.add('active');
      const targetPanel = document.getElementById(targetId);
      if (targetPanel) targetPanel.classList.add('active');

      // Refresh grocery list if switching to grocery tab
      if (targetId === 'tab-grocery' && AppState.currentPlan) {
        refreshGroceryList();
      }
    });
  });
}

/**
 * Profiler Intake Form Handler
 */
function setupProfilerForm() {
  const form = document.getElementById('formProfiler');
  const budgetInput = document.getElementById('inputBudget');
  const pills = document.querySelectorAll('.budget-pill');

  // Quick budget pill buttons
  pills.forEach(pill => {
    pill.addEventListener('click', () => {
      pills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      budgetInput.value = pill.getAttribute('data-val');
    });
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const dailyBudget = Number(budgetInput.value);
    const dietPreference = form.querySelector('input[name="dietPreference"]:checked').value;
    const fitnessGoal = form.querySelector('input[name="fitnessGoal"]:checked').value;

    AppState.dailyBudget = dailyBudget;
    AppState.dietPreference = dietPreference;
    AppState.fitnessGoal = fitnessGoal;

    await runOptimization({
      dailyBudget,
      dietPreference,
      fitnessGoal,
      priceMultiplier: AppState.priceMultiplier,
      pantryIngredients: AppState.pantryItemsSelected
    });
  });
}

/**
 * Runs Knapsack Optimization Algorithm via API
 */
async function runOptimization(params) {
  const submitBtn = document.getElementById('btnGeneratePlan');
  const originalText = submitBtn.innerHTML;

  try {
    submitBtn.disabled = true;
    submitBtn.innerHTML = '⚙️ Optimizing Knapsack...';

    const result = await API.optimizeMealPlan(params);

    if (result && result.meals) {
      AppState.setPlan(result);
      updatePlanUI(result);
      UI.showToast(`Optimal ₹${result.totals.cost} meal plan assembled successfully!`, 'success');
    }
  } catch (err) {
    console.error('Optimization error:', err);
    UI.showToast(err.message, 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = originalText;
  }
}

/**
 * Updates UI with generated plan
 */
function updatePlanUI(plan) {
  // Update Cards
  UI.renderMealCards(plan.meals);

  // Update Visualizer (Counters, Chart.js doughnut, RDA progress tracks)
  ChartsManager.updateVisualizer(plan.totals, plan.macroPercentages, plan.meta?.rdaTargets);

  // Attach card action listeners (Swap & Recipe)
  attachCardActionListeners();
}

/**
 * Card Action Listeners for Meal Swap & Recipe Breakdown
 */
function attachCardActionListeners() {
  // One-Click Swap Trigger
  document.querySelectorAll('.btn-swap-trigger').forEach(btn => {
    btn.addEventListener('click', async () => {
      const slotKey = btn.getAttribute('data-slot');
      await openSwapModal(slotKey);
    });
  });

  // Recipe Details Trigger
  document.querySelectorAll('.btn-recipe-trigger').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-id');
      await openRecipeModal(id);
    });
  });
}

/**
 * Opens Meal Swap Modal with ranked alternative dishes
 */
async function openSwapModal(slotKey) {
  if (!AppState.currentPlan) return;

  try {
    const res = await API.getSwapOptions({
      currentMeals: AppState.currentPlan.meals,
      slotKey,
      dailyBudget: AppState.dailyBudget,
      priceMultiplier: AppState.priceMultiplier
    });

    UI.renderSwapModal(slotKey, res.alternatives, async (slot, replacementId) => {
      await executeMealSwap(slot, replacementId);
    });
  } catch (err) {
    UI.showToast(`Could not fetch swap options: ${err.message}`, 'error');
  }
}

/**
 * Executes Meal Swap
 */
async function executeMealSwap(slotKey, replacementRecipeId) {
  try {
    const res = await API.executeSwap({
      currentPlan: AppState.currentPlan,
      slotKey,
      replacementRecipeId
    });

    if (res.success && res.plan) {
      AppState.setPlan(res.plan);
      updatePlanUI(res.plan);
      UI.showToast(`Swapped ${slotKey} successfully! New cost: ₹${res.plan.totals.cost}`, 'success');
    }
  } catch (err) {
    UI.showToast(`Swap failed: ${err.message}`, 'error');
  }
}

/**
 * Opens Recipe & Prep Breakdown Modal
 */
async function openRecipeModal(recipeId) {
  try {
    const res = await API.getRecipeById(recipeId);
    if (res.success && res.recipe) {
      UI.renderRecipeDetailModal(res.recipe);
    }
  } catch (err) {
    UI.showToast(`Could not load recipe details: ${err.message}`, 'error');
  }
}

/**
 * Official Hackathon Demo Button Handler
 */
function setupDemoButton() {
  const btn = document.getElementById('btnQuickDemo');
  if (!btn) return;

  btn.addEventListener('click', async () => {
    // 1. Set form values
    document.getElementById('inputBudget').value = 120;
    document.querySelector('input[name="dietPreference"][value="non-veg"]').checked = true;
    document.querySelector('input[name="fitnessGoal"][value="Muscle Gain"]').checked = true;

    // Reset slider
    const slider = document.getElementById('priceSlider');
    if (slider) slider.value = 1.0;
    document.getElementById('priceMultiplierVal').textContent = '1.0x';
    AppState.priceMultiplier = 1.0;

    // Switch to optimizer tab
    document.querySelector('.tab-btn[data-tab="tab-optimizer"]').click();

    // Run Optimization
    await runOptimization({
      dailyBudget: 120,
      dietPreference: 'non-veg',
      fitnessGoal: 'Muscle Gain',
      priceMultiplier: 1.0,
      pantryIngredients: []
    });

    UI.showToast('Official ₹120 High Protein Hackathon Demo loaded!', 'success');
  });
}

/**
 * Regional Price Adjustment Slider
 */
function setupRegionalPriceSlider() {
  const slider = document.getElementById('priceSlider');
  const valDisplay = document.getElementById('priceMultiplierVal');
  if (!slider) return;

  slider.addEventListener('input', (e) => {
    const val = Number(e.target.value);
    valDisplay.textContent = `${val.toFixed(2)}x`;
    AppState.setPriceMultiplier(val);
  });

  slider.addEventListener('change', async () => {
    if (AppState.currentPlan) {
      UI.showToast(`Recalculating with ${AppState.priceMultiplier}x regional index...`, 'info');
      await runOptimization({
        dailyBudget: AppState.dailyBudget,
        dietPreference: AppState.dietPreference,
        fitnessGoal: AppState.fitnessGoal,
        priceMultiplier: AppState.priceMultiplier,
        pantryIngredients: AppState.pantryItemsSelected
      });
    }
  });
}

/**
 * Smart Grocery Shopping List
 */
function setupGroceryDurationSelector() {
  const select = document.getElementById('groceryDaysSelect');
  if (!select) return;

  select.addEventListener('change', () => {
    AppState.groceryDays = Number(select.value);
    refreshGroceryList();
  });
}

async function refreshGroceryList() {
  if (!AppState.currentPlan || !AppState.currentPlan.meals) return;

  try {
    const res = await API.getGroceryList(
      AppState.currentPlan.meals,
      AppState.groceryDays,
      AppState.priceMultiplier
    );
    if (res.success && res.groceryList) {
      AppState.groceryList = res.groceryList;
      UI.renderGroceryList(res.groceryList);
    }
  } catch (err) {
    console.error('Grocery list load error:', err);
  }
}

/**
 * Hostel Mess Guide Loader
 */
async function loadHostelMessGuide() {
  try {
    const res = await API.getHostelMessGuide();
    if (res.success && res.schedule) {
      AppState.hostelMessSchedule = res.schedule;
      UI.renderHostelMessGuide(res.schedule);
    }
  } catch (err) {
    console.error('Hostel mess guide error:', err);
  }
}

/**
 * Pantry Leftover Optimizer
 */
function setupPantryOptimizer() {
  const btn = document.getElementById('btnRecalculatePantry');
  if (!btn) return;

  btn.addEventListener('click', async () => {
    const checkboxes = document.querySelectorAll('.pantry-item-cb:checked');
    const checkedIds = Array.from(checkboxes).map(c => c.value);
    AppState.pantryItemsSelected = checkedIds;

    try {
      btn.disabled = true;
      btn.textContent = 'Calculating...';

      const res = await API.optimizePantry(checkedIds, AppState.dietPreference);
      if (res.success) {
        UI.renderPantryResults(res.recommendedRecipes);
        UI.showToast(`Found ${res.recommendedRecipes.length} recipes utilizing your pantry!`, 'success');
      }
    } catch (err) {
      UI.showToast(err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = '🔍 Recalculate With My Pantry Leftovers';
    }
  });
}

async function loadPantryInventory() {
  try {
    const res = await API.getPantryItems();
    if (res.success && res.pantryItems) {
      UI.renderPantryChecklist(res.pantryItems, (checked) => {
        AppState.pantryItemsSelected = checked;
      });
    }
  } catch (err) {
    console.error('Pantry load error:', err);
  }
}

/**
 * Community Board Features
 */
function setupCommunityFeatures() {
  const form = document.getElementById('formCommunityRecipe');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const payload = {
      title: document.getElementById('commTitle').value.trim(),
      author_name: document.getElementById('commAuthor').value.trim(),
      dorm_room: document.getElementById('commDorm').value.trim(),
      cost: Number(document.getElementById('commCost').value),
      protein: Number(document.getElementById('commProtein').value),
      calories: Number(document.getElementById('commCalories').value),
      diet_type: document.getElementById('commDiet').value,
      ingredients: document.getElementById('commIngredients').value.trim(),
      instructions: document.getElementById('commInstructions').value.trim()
    };

    try {
      const res = await API.submitCommunityRecipe(payload);
      if (res.success) {
        UI.showToast('Recipe posted to campus board!', 'success');
        form.reset();
        await loadCommunityFeed();
      }
    } catch (err) {
      UI.showToast(err.message, 'error');
    }
  });
}

async function loadCommunityFeed() {
  try {
    const res = await API.getCommunityRecipes();
    if (res.success && res.recipes) {
      AppState.communityRecipes = res.recipes;
      UI.renderCommunityFeed(res.recipes, async (recipeId) => {
        try {
          const upRes = await API.upvoteCommunityRecipe(recipeId);
          if (upRes.success) {
            UI.showToast('Upvoted student recipe! 👍', 'success');
            await loadCommunityFeed();
          }
        } catch (e) {
          UI.showToast(e.message, 'error');
        }
      });
    }
  } catch (err) {
    console.error('Community feed load error:', err);
  }
}

/**
 * 50 Indian Staples Catalog
 */
function setupCatalogFilters() {
  const chips = document.querySelectorAll('.filter-chip');
  const searchInput = document.getElementById('recipeSearchInput');

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      filterAndRenderCatalog();
    });
  });

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      filterAndRenderCatalog();
    });
  }
}

async function loadRecipeCatalog() {
  try {
    const res = await API.getRecipes();
    if (res.success && res.recipes) {
      AppState.catalogRecipes = res.recipes;
      UI.renderRecipeCatalog(res.recipes);
      attachCardActionListeners();
    }
  } catch (err) {
    console.error('Catalog load error:', err);
  }
}

function filterAndRenderCatalog() {
  const activeChip = document.querySelector('.filter-chip.active');
  const filter = activeChip ? activeChip.getAttribute('data-filter') : 'all';
  const searchTerm = (document.getElementById('recipeSearchInput')?.value || '').toLowerCase();

  let filtered = [...AppState.catalogRecipes];

  if (filter === 'breakfast' || filter === 'lunch' || filter === 'snack' || filter === 'dinner') {
    filtered = filtered.filter(r => r.meal_type === filter);
  } else if (filter === 'veg') {
    filtered = filtered.filter(r => r.diet_type === 'veg' || r.diet_type === 'vegan');
  } else if (filter === 'vegan') {
    filtered = filtered.filter(r => r.diet_type === 'vegan');
  }

  if (searchTerm) {
    filtered = filtered.filter(r =>
      r.name.toLowerCase().includes(searchTerm) ||
      (r.primary_protein && r.primary_protein.toLowerCase().includes(searchTerm))
    );
  }

  UI.renderRecipeCatalog(filtered);
  attachCardActionListeners();
}

/**
 * Printable Refrigerator Cheat Sheet
 */
function setupPrintCheatSheet() {
  const btn = document.getElementById('btnPrintPlan');
  if (!btn) return;

  btn.addEventListener('click', () => {
    window.print();
  });
}

/**
 * Modal Close Handlers
 */
function setupModals() {
  const modalSwap = document.getElementById('modalSwap');
  const modalDetail = document.getElementById('modalRecipeDetail');

  document.getElementById('btnCloseSwapModal')?.addEventListener('click', () => {
    modalSwap.classList.add('hidden');
  });

  document.getElementById('btnCloseDetailModal')?.addEventListener('click', () => {
    modalDetail.classList.add('hidden');
  });

  // Close when clicking backdrop
  [modalSwap, modalDetail].forEach(modal => {
    if (!modal) return;
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.add('hidden');
      }
    });
  });

  // Save Plan Button
  document.getElementById('btnSavePlan')?.addEventListener('click', async () => {
    if (!AppState.currentPlan) return;
    try {
      const res = await API.savePlan('Saved Student Plan', AppState.currentPlan);
      if (res.success) {
        UI.showToast(`Plan successfully saved to SQLite database (ID: ${res.planId})`, 'success');
      }
    } catch (err) {
      UI.showToast(`Failed to save plan: ${err.message}`, 'error');
    }
  });
}

/**
 * Theme Toggle (Light / Dark Mode)
 */
function setupThemeToggle() {
  const btn = document.getElementById('btnThemeToggle');
  if (!btn) return;

  const currentTheme = localStorage.getItem('platepilot_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', currentTheme);
  btn.textContent = currentTheme === 'dark' ? '☀️' : '🌙';

  btn.addEventListener('click', () => {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const nextTheme = isDark ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', nextTheme);
    localStorage.setItem('platepilot_theme', nextTheme);
    btn.textContent = nextTheme === 'dark' ? '☀️' : '🌙';
  });
}

/**
 * Bootstraps initial meal plan (loads demo automatically if no saved plan)
 */
async function loadInitialPlan() {
  if (AppState.currentPlan) {
    updatePlanUI(AppState.currentPlan);
  } else {
    // Automatically run demo on fresh visit
    await runOptimization({
      dailyBudget: 120,
      dietPreference: 'non-veg',
      fitnessGoal: 'Muscle Gain',
      priceMultiplier: 1.0,
      pantryIngredients: []
    });
  }
}
