/**
 * PlatePilot UI View Renderers
 * Pure, accessible, modular DOM renderers for meal cards, modals, tables, and notifications.
 */

const UI = {
  // Toast Notification System
  showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;

    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  },

  // Render Assembled Meal Plan Cards
  renderMealCards(meals) {
    const container = document.getElementById('mealCardsContainer');
    if (!container) return;

    if (!meals || meals.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p>No meals generated yet. Click "Run Knapsack Optimization" above.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = meals.map(meal => {
      // Ingredients preview (top 3)
      const ingPreview = (meal.ingredients || []).slice(0, 3).map(ing => `
        <div class="ingredient-cost-preview">
          <span>• ${ing.name}</span>
          <strong>₹${ing.cost}</strong>
        </div>
      `).join('');

      const dietEmoji = meal.diet_type === 'non-veg' ? '🍗' : (meal.diet_type === 'vegan' ? '🌱' : '🥦');

      return `
        <div class="meal-card" data-slot="${meal.slotKey}">
          <div>
            <div class="meal-card-top">
              <span class="meal-slot-badge">${dietEmoji} ${meal.slot}</span>
              <span class="meal-cost-badge">₹${meal.cost}</span>
            </div>

            <h3 class="meal-card-title">${meal.name}</h3>

            <div class="meal-macro-pills">
              <span class="macro-pill p-protein">${meal.protein}g Prot</span>
              <span class="macro-pill p-cal">${meal.calories} kcal</span>
              <span class="macro-pill p-carbs">${meal.carbs}g Carb</span>
              <span class="macro-pill p-fats">${meal.fats}g Fat</span>
            </div>

            <div class="meal-card-ingredients">
              ${ingPreview}
              ${(meal.ingredients || []).length > 3 ? `<small class="text-muted">+${meal.ingredients.length - 3} more ingredients</small>` : ''}
            </div>
          </div>

          <div class="meal-card-actions">
            <button class="btn btn-outline btn-sm btn-swap-trigger" data-slot="${meal.slotKey}">
              🔄 Swap Meal
            </button>
            <button class="btn btn-secondary btn-sm btn-recipe-trigger" data-id="${meal.id}">
              📖 Recipe & Prep
            </button>
          </div>
        </div>
      `;
    }).join('');
  },

  // Render One-Click Meal Swap Modal
  renderSwapModal(slotKey, alternatives, onSelectSwap) {
    const modal = document.getElementById('modalSwap');
    const title = document.getElementById('swapModalTitle');
    const desc = document.getElementById('swapModalDesc');
    const list = document.getElementById('swapAlternativesList');

    if (!modal || !list) return;

    title.textContent = `🔄 Swap ${slotKey.toUpperCase()} Dish`;
    desc.textContent = `Pick a nutritionally equivalent replacement that strictly respects your ₹${AppState.dailyBudget} daily budget cap:`;

    if (!alternatives || alternatives.length === 0) {
      list.innerHTML = `<p class="empty-msg">No alternative dishes found under the remaining budget for this slot.</p>`;
      modal.classList.remove('hidden');
      return;
    }

    list.innerHTML = alternatives.map(alt => {
      const deltaSign = alt.costDelta > 0 ? `+₹${alt.costDelta}` : (alt.costDelta < 0 ? `-₹${Math.abs(alt.costDelta)}` : '₹0');
      const dietEmoji = alt.diet_type === 'non-veg' ? '🍗' : (alt.diet_type === 'vegan' ? '🌱' : '🥦');

      return `
        <div class="swap-alt-card">
          <div class="swap-alt-info">
            <div style="font-weight: 700; margin-bottom: 0.2rem;">
              ${dietEmoji} ${alt.name}
            </div>
            <div class="meal-macro-pills">
              <span class="macro-pill p-protein">${alt.protein}g Prot</span>
              <span class="macro-pill p-cal">${alt.calories} kcal</span>
              <span class="macro-pill">Cost: ₹${alt.cost} (${deltaSign})</span>
              <span class="macro-pill">New Daily Total: ₹${alt.newTotalCost}</span>
            </div>
          </div>
          <button class="btn btn-primary btn-sm btn-apply-swap" data-id="${alt.id}" data-slot="${slotKey}">
            Select & Swap
          </button>
        </div>
      `;
    }).join('');

    modal.classList.remove('hidden');

    // Attach click events to swap buttons
    const buttons = list.querySelectorAll('.btn-apply-swap');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const recipeId = Number(btn.getAttribute('data-id'));
        modal.classList.add('hidden');
        if (typeof onSelectSwap === 'function') {
          onSelectSwap(slotKey, recipeId);
        }
      });
    });
  },

  // Render Detailed Recipe & Cooking Breakdown Modal
  renderRecipeDetailModal(recipe) {
    const modal = document.getElementById('modalRecipeDetail');
    const title = document.getElementById('detailRecipeTitle');
    const body = document.getElementById('detailModalBody');

    if (!modal || !body) return;

    title.textContent = `${recipe.name} (₹${recipe.cost})`;

    const ingsList = (recipe.ingredients || []).map(i => `
      <li style="display: flex; justify-content: space-between; padding: 0.35rem 0; border-bottom: 1px dashed rgba(255,255,255,0.08);">
        <span>${i.name} (${i.qty})</span>
        <strong style="font-family: var(--font-mono);">₹${i.cost}</strong>
      </li>
    `).join('');

    const stepsList = (recipe.instructions || []).map((step, idx) => `
      <li style="margin-bottom: 0.5rem;">
        <strong style="color: var(--accent-primary);">Step ${idx + 1}:</strong> ${step}
      </li>
    `).join('');

    body.innerHTML = `
      <div style="margin-bottom: 1rem;">
        <div class="meal-macro-pills" style="margin-bottom: 0.75rem;">
          <span class="macro-pill p-protein">${recipe.protein}g Protein</span>
          <span class="macro-pill p-cal">${recipe.calories} kcal</span>
          <span class="macro-pill p-carbs">${recipe.carbs}g Carbs</span>
          <span class="macro-pill p-fats">${recipe.fats}g Fats</span>
          <span class="macro-pill">⏱️ ${recipe.prep_time} mins</span>
          ${recipe.is_hostel_friendly ? '<span class="badge badge-success">⚡ Kettle / Induction Friendly</span>' : ''}
        </div>
      </div>

      <div style="margin-bottom: 1.25rem;">
        <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.5rem; color: var(--accent-primary);">
          🛒 Per-Meal Ingredient Cost Breakdown:
        </h4>
        <ul style="list-style: none; font-size: 0.85rem;">
          ${ingsList}
        </ul>
      </div>

      <div>
        <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.5rem; color: var(--accent-primary);">
          🍳 Simple Hostel-Friendly Cooking Instructions:
        </h4>
        <ol style="padding-left: 1.25rem; font-size: 0.85rem; line-height: 1.5;">
          ${stepsList}
        </ol>
      </div>
    `;

    modal.classList.remove('hidden');
  },

  // Render Smart Grocery List
  renderGroceryList(groceryData) {
    const container = document.getElementById('groceryCategoriesContainer');
    const txtSpend = document.getElementById('txtWeeklySpend');
    const txtSavings = document.getElementById('txtBulkSavings');

    if (!container || !groceryData) return;

    if (txtSpend) txtSpend.textContent = `₹${groceryData.totalEstimatedWeeklySpend}`;
    if (txtSavings) txtSavings.textContent = `₹${groceryData.potentialBulkSavings} (${groceryData.savingsPercentage}%)`;

    const categories = groceryData.categories || {};
    let html = '';

    for (const [catName, items] of Object.entries(categories)) {
      if (!items || items.length === 0) continue;

      const rows = items.map(item => `
        <tr>
          <td>
            <strong>${item.name}</strong>
            ${item.bulkAvailable ? `<br><small style="color: var(--text-muted);">Bulk pack: ${item.bulkSize} @ ₹${item.bulkPrice}</small>` : ''}
          </td>
          <td style="color: var(--accent-primary);">₹${item.weeklyCost}</td>
        </tr>
      `).join('');

      html += `
        <div class="grocery-category-card">
          <div class="grocery-category-title">
            <span>${catName}</span>
            <span style="font-size: 0.8rem; color: var(--text-muted);">${items.length} items</span>
          </div>
          <table class="grocery-items-table">
            <tbody>
              ${rows}
            </tbody>
          </table>
        </div>
      `;
    }

    container.innerHTML = html;
  },

  // Render Hostel Mess Alternative Schedule
  renderHostelMessGuide(schedule) {
    const container = document.getElementById('hostelMessContainer');
    if (!container || !schedule) return;

    container.innerHTML = schedule.map(dayItem => {
      const suppList = (dayItem.supplements || []).map(s => `
        <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
          <span>• ${s.item}</span>
          <strong style="font-family: var(--font-mono); color: var(--accent-primary);">+₹${s.cost} (${s.protein}g)</strong>
        </div>
      `).join('');

      return `
        <div class="mess-day-card">
          <div>
            <div class="mess-day-title">${dayItem.day}</div>
            <span class="badge badge-warning" style="margin-top: 0.25rem;">${dayItem.messRating}</span>
          </div>

          <div class="mess-action-plan">
            <strong style="color: var(--text-primary); font-size: 0.9rem;">${dayItem.messMeal}</strong>
            <p>${dayItem.actionPlan}</p>
          </div>

          <div class="mess-supplements-box">
            <strong style="color: var(--accent-primary); display: block; margin-bottom: 0.35rem;">
              💡 Outside Superfood Hack:
            </strong>
            ${suppList}
            <div style="border-top: 1px dashed rgba(16,185,129,0.3); padding-top: 0.35rem; margin-top: 0.35rem; display: flex; justify-content: space-between; font-weight: 700;">
              <span>Extra Spend: ₹${dayItem.totalExtraCost}</span>
              <span style="color: #f43f5e;">Total Prot: ${dayItem.boostedProtein}</span>
            </div>
          </div>
        </div>
      `;
    }).join('');
  },

  // Render Pantry Leftovers
  renderPantryChecklist(items, onToggle) {
    const container = document.getElementById('pantryCheckboxes');
    if (!container || !items) return;

    container.innerHTML = items.map(item => `
      <label class="pantry-check-item">
        <input type="checkbox" value="${item.id}" class="pantry-item-cb">
        <span>${item.name}</span>
      </label>
    `).join('');

    const checkboxes = container.querySelectorAll('.pantry-item-cb');
    checkboxes.forEach(cb => {
      cb.addEventListener('change', () => {
        const checked = Array.from(checkboxes).filter(c => c.checked).map(c => c.value);
        if (typeof onToggle === 'function') onToggle(checked);
      });
    });
  },

  renderPantryResults(recipes) {
    const container = document.getElementById('pantryRecipeResults');
    if (!container) return;

    if (!recipes || recipes.length === 0) {
      container.innerHTML = `<p class="empty-msg">Select pantry items above to see recipes with reduced out-of-pocket spend.</p>`;
      return;
    }

    container.innerHTML = recipes.map(r => `
      <div class="meal-card" style="padding: 1rem;">
        <div class="meal-card-top">
          <span class="meal-slot-badge">${r.meal_type}</span>
          <span class="meal-cost-badge">₹${r.netOutOfPocketCost}</span>
        </div>
        <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.35rem;">${r.name}</h4>
        <div style="font-size: 0.8rem; color: var(--text-secondary); margin-bottom: 0.5rem;">
          Regular: <s>₹${r.cost}</s> | <strong style="color: var(--accent-primary);">Saved ₹${r.estimatedRupeeSavings}</strong> using dorm pantry!
        </div>
        <div class="meal-macro-pills">
          <span class="macro-pill p-protein">${r.protein}g Prot</span>
          <span class="macro-pill p-cal">${r.calories} kcal</span>
        </div>
      </div>
    `).join('');
  },

  // Render Community Recipe Board
  renderCommunityFeed(recipes, onUpvote) {
    const container = document.getElementById('communityFeedContainer');
    if (!container || !recipes) return;

    container.innerHTML = recipes.map(r => `
      <div class="community-post">
        <div class="community-post-header">
          <div>
            <h3 style="font-size: 1.1rem; font-weight: 700;">${r.title}</h3>
            <span class="community-post-meta">Shared by ${r.author_name} (${r.dorm_room}) • ${r.diet_type}</span>
          </div>
          <button class="community-upvote-btn" data-id="${r.id}">
            ▲ <span class="vote-count">${r.upvotes}</span>
          </button>
        </div>

        <div class="meal-macro-pills" style="margin: 0.5rem 0;">
          <span class="macro-pill p-protein">${r.protein}g Protein</span>
          <span class="macro-pill p-cal">${r.calories} kcal</span>
          <span class="macro-pill" style="color: var(--accent-primary);">Cost: ₹${r.cost}</span>
          <span class="macro-pill">⏱️ ${r.prep_time}m prep</span>
          <span class="badge badge-success">✓ Verified Student Hack</span>
        </div>

        <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 0.5rem;">
          <strong>Ingredients:</strong> ${r.ingredients}
        </p>
        <p style="font-size: 0.85rem; color: var(--text-secondary);">
          <strong>Instructions:</strong> ${r.instructions}
        </p>
      </div>
    `).join('');

    const upvoteButtons = container.querySelectorAll('.community-upvote-btn');
    upvoteButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        if (typeof onUpvote === 'function') onUpvote(id);
      });
    });
  },

  // Render 50 Staples Catalog
  renderRecipeCatalog(recipes) {
    const container = document.getElementById('recipeCatalogGrid');
    if (!container || !recipes) return;

    container.innerHTML = recipes.map(r => `
      <div class="catalog-item-card">
        <div>
          <div class="meal-card-top">
            <span class="meal-slot-badge">${r.meal_type}</span>
            <span class="meal-cost-badge">₹${r.cost}</span>
          </div>
          <h4 style="font-size: 1rem; font-weight: 700; margin-bottom: 0.4rem;">${r.name}</h4>
          <div class="meal-macro-pills">
            <span class="macro-pill p-protein">${r.protein}g Prot</span>
            <span class="macro-pill p-cal">${r.calories} kcal</span>
          </div>
        </div>
        <button class="btn btn-secondary btn-sm btn-recipe-trigger" data-id="${r.id}" style="margin-top: 0.75rem;">
          View Ingredients & Prep
        </button>
      </div>
    `).join('');
  }
};
