/**
 * PlatePilot REST API Router
 * All endpoints for meal optimization, swaps, groceries, recipes, and stretch features.
 */

const express = require('express');
const router = express.Router();

const {
  validateOptimizeRequest,
  validateSwapRequest,
  validateCommunityRecipeRequest
} = require('../middleware/validation');

const {
  optimizeMealPlan,
  getSwapOptions,
  executeSwap,
  getGroceryShoppingList,
  saveMealPlan,
  getSavedPlans
} = require('../controllers/planController');

const {
  getAllRecipes,
  getRecipeById
} = require('../controllers/recipeController');

const {
  getRDAGoals,
  saveBudgetProfile
} = require('../controllers/budgetController');

const {
  getHostelMessGuide,
  getPantryList,
  optimizePantryLeftovers,
  getCommunityRecipes,
  submitCommunityRecipe,
  upvoteCommunityRecipe
} = require('../controllers/stretchController');

// Health Check
router.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '2.0.0',
    database: 'SQLite (Native DatabaseSync)',
    features: [
      'Multi-Choice Knapsack Optimizer',
      'One-Click Meal Swap Engine',
      'Chart.js RDA Balance Visualizer',
      'Smart Bulk Grocery List',
      'Hostel Mess Alternative Mode',
      'Pantry Leftover Optimizer',
      'Community Recipe Board',
      'PDF Print Cheat Sheet'
    ]
  });
});

// Profiler & RDA
router.get('/budget/rda', getRDAGoals);
router.post('/budget/profile', saveBudgetProfile);

// Optimization & Swaps
router.post('/optimize', validateOptimizeRequest, optimizeMealPlan);
router.post('/swap/options', validateSwapRequest, getSwapOptions);
router.post('/swap/execute', validateSwapRequest, executeSwap);

// Groceries & Persistence
router.post('/grocery-list', getGroceryShoppingList);
router.post('/plans/save', saveMealPlan);
router.get('/plans/saved', getSavedPlans);

// Recipe Catalog
router.get('/recipes', getAllRecipes);
router.get('/recipes/:id', getRecipeById);

// Stretch Features
router.get('/hostel-mess', getHostelMessGuide);
router.get('/pantry/items', getPantryList);
router.post('/pantry/optimize', optimizePantryLeftovers);
router.get('/community-recipes', getCommunityRecipes);
router.post('/community-recipes', validateCommunityRecipeRequest, submitCommunityRecipe);
router.post('/community-recipes/:id/upvote', upvoteCommunityRecipe);

module.exports = router;
