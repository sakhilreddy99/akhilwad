/**
 * Input Validation Middleware for PlatePilot
 * Enforces strict typing, range checking, and schema validation on all incoming payloads.
 */

function validateOptimizeRequest(req, res, next) {
  const { dailyBudget, dietPreference, fitnessGoal, priceMultiplier } = req.body;

  const errors = [];

  // dailyBudget validation
  const budgetNum = Number(dailyBudget);
  if (dailyBudget === undefined || dailyBudget === null || isNaN(budgetNum)) {
    errors.push('Field "dailyBudget" is required and must be a valid number.');
  } else if (budgetNum < 50 || budgetNum > 1000) {
    errors.push('Daily budget must be between ₹50 and ₹1,000.');
  }

  // dietPreference validation
  const validDiets = ['veg', 'non-veg', 'vegan'];
  if (dietPreference && !validDiets.includes(dietPreference.toLowerCase())) {
    errors.push(`Invalid dietPreference "${dietPreference}". Allowed: ${validDiets.join(', ')}.`);
  }

  // fitnessGoal validation
  const validGoals = ['Muscle Gain', 'High Protein', 'Weight Loss', 'Maintenance'];
  if (fitnessGoal && !validGoals.includes(fitnessGoal)) {
    errors.push(`Invalid fitnessGoal "${fitnessGoal}". Allowed: ${validGoals.join(', ')}.`);
  }

  // priceMultiplier validation
  if (priceMultiplier !== undefined) {
    const multNum = Number(priceMultiplier);
    if (isNaN(multNum) || multNum < 0.5 || multNum > 2.0) {
      errors.push('priceMultiplier must be a number between 0.5 and 2.0.');
    }
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      error: 'Validation failed',
      details: errors
    });
  }

  req.validatedBody = {
    dailyBudget: budgetNum,
    dietPreference: (dietPreference || 'veg').toLowerCase(),
    fitnessGoal: fitnessGoal || 'Muscle Gain',
    priceMultiplier: priceMultiplier ? Number(priceMultiplier) : 1.0,
    pantryIngredients: Array.isArray(req.body.pantryIngredients) ? req.body.pantryIngredients : []
  };

  next();
}

function validateSwapRequest(req, res, next) {
  const { currentPlan, slotKey, replacementRecipeId } = req.body;
  const errors = [];

  if (!currentPlan || !Array.isArray(currentPlan.meals) || currentPlan.meals.length === 0) {
    errors.push('Field "currentPlan" with a non-empty meals array is required.');
  }

  const validSlots = ['breakfast', 'lunch', 'snack', 'dinner'];
  if (!slotKey || !validSlots.includes(slotKey.toLowerCase())) {
    errors.push(`Field "slotKey" must be one of: ${validSlots.join(', ')}.`);
  }

  if (replacementRecipeId !== undefined) {
    const idNum = Number(replacementRecipeId);
    if (isNaN(idNum) || idNum <= 0) {
      errors.push('Field "replacementRecipeId" must be a positive integer.');
    }
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      error: 'Validation failed',
      details: errors
    });
  }

  next();
}

function validateCommunityRecipeRequest(req, res, next) {
  const { title, author_name, cost, calories, protein, prep_time, ingredients, instructions } = req.body;
  const errors = [];

  if (!title || typeof title !== 'string' || title.trim().length < 3) {
    errors.push('Recipe title must be at least 3 characters long.');
  }
  if (!author_name || typeof author_name !== 'string') {
    errors.push('Author name is required.');
  }
  if (isNaN(Number(cost)) || Number(cost) <= 0 || Number(cost) > 500) {
    errors.push('Cost must be between ₹1 and ₹500.');
  }
  if (isNaN(Number(calories)) || Number(calories) < 50 || Number(calories) > 2000) {
    errors.push('Calories must be between 50 and 2000 kcal.');
  }
  if (isNaN(Number(protein)) || Number(protein) < 0 || Number(protein) > 150) {
    errors.push('Protein must be between 0g and 150g.');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      error: 'Validation failed',
      details: errors
    });
  }

  next();
}

module.exports = {
  validateOptimizeRequest,
  validateSwapRequest,
  validateCommunityRecipeRequest
};
