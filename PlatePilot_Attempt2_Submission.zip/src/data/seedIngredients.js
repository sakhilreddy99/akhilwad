/**
 * Bulk Ingredient Pricing and Nutrient Database (Realistic Indian Grocery Market Rates)
 * Used for NutrientCosts table and Smart Grocery Shopping List generator.
 */

const SEED_INGREDIENTS = [
  // Grains & Staples
  { name: 'Rolled Oats', category: 'Grains & Staples', unit: 'g', unitPrice: 0.25, bulkSize: '1 kg', bulkPrice: 190, caloriesPer100g: 389, proteinPer100g: 16.9 },
  { name: 'Whole Wheat Flour (Atta)', category: 'Grains & Staples', unit: 'g', unitPrice: 0.045, bulkSize: '5 kg', bulkPrice: 210, caloriesPer100g: 340, proteinPer100g: 12.0 },
  { name: 'White Rice', category: 'Grains & Staples', unit: 'g', unitPrice: 0.05, bulkSize: '5 kg', bulkPrice: 240, caloriesPer100g: 130, proteinPer100g: 2.7 },
  { name: 'Brown Rice', category: 'Grains & Staples', unit: 'g', unitPrice: 0.08, bulkSize: '1 kg', bulkPrice: 75, caloriesPer100g: 111, proteinPer100g: 2.6 },
  { name: 'Poha (Flattened Rice)', category: 'Grains & Staples', unit: 'g', unitPrice: 0.06, bulkSize: '1 kg', bulkPrice: 55, caloriesPer100g: 350, proteinPer100g: 6.8 },
  { name: 'Semolina (Sooji / Rava)', category: 'Grains & Staples', unit: 'g', unitPrice: 0.05, bulkSize: '1 kg', bulkPrice: 48, caloriesPer100g: 360, proteinPer100g: 12.7 },
  { name: 'Besan (Gram Flour)', category: 'Grains & Staples', unit: 'g', unitPrice: 0.09, bulkSize: '1 kg', bulkPrice: 85, caloriesPer100g: 387, proteinPer100g: 22.4 },
  { name: 'Whole Wheat Bread', category: 'Grains & Staples', unit: 'slices', unitPrice: 2.5, bulkSize: '1 Loaf (400g)', bulkPrice: 45, caloriesPer100g: 247, proteinPer100g: 12.0 },
  { name: 'Sattu Flour', category: 'Grains & Staples', unit: 'g', unitPrice: 0.12, bulkSize: '500g', bulkPrice: 55, caloriesPer100g: 413, proteinPer100g: 25.6 },

  // Legumes & Pulses (High Protein Staples)
  { name: 'Soya Chunks', category: 'Proteins & Pulses', unit: 'g', unitPrice: 0.14, bulkSize: '1 kg', bulkPrice: 130, caloriesPer100g: 345, proteinPer100g: 52.0 },
  { name: 'Yellow Moong Dal', category: 'Proteins & Pulses', unit: 'g', unitPrice: 0.13, bulkSize: '1 kg', bulkPrice: 125, caloriesPer100g: 347, proteinPer100g: 24.0 },
  { name: 'Toor Dal (Arhar)', category: 'Proteins & Pulses', unit: 'g', unitPrice: 0.16, bulkSize: '1 kg', bulkPrice: 155, caloriesPer100g: 343, proteinPer100g: 22.0 },
  { name: 'Rajma (Kidney Beans)', category: 'Proteins & Pulses', unit: 'g', unitPrice: 0.14, bulkSize: '1 kg', bulkPrice: 135, caloriesPer100g: 333, proteinPer100g: 24.0 },
  { name: 'Chole (Kabuli Chana)', category: 'Proteins & Pulses', unit: 'g', unitPrice: 0.15, bulkSize: '1 kg', bulkPrice: 140, caloriesPer100g: 364, proteinPer100g: 19.0 },
  { name: 'Kala Chana (Black Chickpeas)', category: 'Proteins & Pulses', unit: 'g', unitPrice: 0.10, bulkSize: '1 kg', bulkPrice: 95, caloriesPer100g: 378, proteinPer100g: 20.0 },
  { name: 'Roasted Chana (Bhuna)', category: 'Proteins & Pulses', unit: 'g', unitPrice: 0.16, bulkSize: '500g', bulkPrice: 75, caloriesPer100g: 369, proteinPer100g: 22.5 },
  { name: 'Whole Green Moong', category: 'Proteins & Pulses', unit: 'g', unitPrice: 0.13, bulkSize: '1 kg', bulkPrice: 120, caloriesPer100g: 347, proteinPer100g: 24.0 },
  { name: 'Masoor Dal (Red Lentil)', category: 'Proteins & Pulses', unit: 'g', unitPrice: 0.11, bulkSize: '1 kg', bulkPrice: 105, caloriesPer100g: 340, proteinPer100g: 24.5 },

  // Dairy & Eggs & Poultry
  { name: 'Eggs', category: 'Dairy & Poultry', unit: 'piece', unitPrice: 7.0, bulkSize: '1 Tray (30 pcs)', bulkPrice: 180, caloriesPer100g: 155, proteinPer100g: 13.0 },
  { name: 'Fresh Paneer', category: 'Dairy & Poultry', unit: 'g', unitPrice: 0.38, bulkSize: '500g', bulkPrice: 180, caloriesPer100g: 265, proteinPer100g: 18.3 },
  { name: 'Curd / Dahi', category: 'Dairy & Poultry', unit: 'g', unitPrice: 0.08, bulkSize: '1 kg', bulkPrice: 75, caloriesPer100g: 61, proteinPer100g: 3.5 },
  { name: 'Toned Milk', category: 'Dairy & Poultry', unit: 'ml', unitPrice: 0.055, bulkSize: '1 Litre', bulkPrice: 54, caloriesPer100g: 58, proteinPer100g: 3.1 },
  { name: 'Chicken Breast (Budget Cut)', category: 'Dairy & Poultry', unit: 'g', unitPrice: 0.28, bulkSize: '1 kg', bulkPrice: 260, caloriesPer100g: 165, proteinPer100g: 31.0 },
  { name: 'Tofu (Soy Paneer)', category: 'Dairy & Poultry', unit: 'g', unitPrice: 0.25, bulkSize: '200g', bulkPrice: 48, caloriesPer100g: 144, proteinPer100g: 15.0 },

  // Nuts, Seeds & Fats
  { name: 'Roasted Peanuts', category: 'Nuts & Healthy Fats', unit: 'g', unitPrice: 0.16, bulkSize: '1 kg', bulkPrice: 150, caloriesPer100g: 567, proteinPer100g: 25.8 },
  { name: 'Peanut Butter', category: 'Nuts & Healthy Fats', unit: 'g', unitPrice: 0.30, bulkSize: '1 kg', bulkPrice: 280, caloriesPer100g: 588, proteinPer100g: 25.0 },
  { name: 'Cooking Mustard/Sunflower Oil', category: 'Nuts & Healthy Fats', unit: 'ml', unitPrice: 0.15, bulkSize: '1 Litre', bulkPrice: 145, caloriesPer100g: 884, proteinPer100g: 0.0 },
  { name: 'Makhana (Foxnuts)', category: 'Nuts & Healthy Fats', unit: 'g', unitPrice: 0.70, bulkSize: '250g', bulkPrice: 165, caloriesPer100g: 347, proteinPer100g: 9.7 },

  // Vegetables & Fresh Produce
  { name: 'Onions', category: 'Fresh Produce', unit: 'g', unitPrice: 0.035, bulkSize: '2 kg', bulkPrice: 65, caloriesPer100g: 40, proteinPer100g: 1.1 },
  { name: 'Tomatoes', category: 'Fresh Produce', unit: 'g', unitPrice: 0.035, bulkSize: '2 kg', bulkPrice: 60, caloriesPer100g: 18, proteinPer100g: 0.9 },
  { name: 'Potatoes', category: 'Fresh Produce', unit: 'g', unitPrice: 0.03, bulkSize: '3 kg', bulkPrice: 75, caloriesPer100g: 77, proteinPer100g: 2.0 },
  { name: 'Palak (Spinach)', category: 'Fresh Produce', unit: 'g', unitPrice: 0.04, bulkSize: '500g', bulkPrice: 20, caloriesPer100g: 23, proteinPer100g: 2.9 },
  { name: 'Bananas', category: 'Fresh Produce', unit: 'piece', unitPrice: 5.0, bulkSize: '1 Dozen', bulkPrice: 50, caloriesPer100g: 89, proteinPer100g: 1.1 },
  { name: 'Green Chillies & Ginger Garlic', category: 'Fresh Produce', unit: 'serving', unitPrice: 3.0, bulkSize: 'Weekly Pack', bulkPrice: 25, caloriesPer100g: 40, proteinPer100g: 1.0 }
];

module.exports = { SEED_INGREDIENTS };
