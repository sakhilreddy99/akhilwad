/**
 * Hostel Mess Menu Mapping & Cheap Outside Supplement Pairing
 * Powers the "Hostel Mess Alternative Mode" stretch feature.
 */

const HOSTEL_MESS_GUIDE = [
  {
    day: 'Monday',
    messMeal: 'Breakfast: Poha / Upma + Tea',
    messRating: 'Low Protein (6g)',
    actionPlan: 'Eat 1 plate mess poha for carbs. Do not skip breakfast.',
    recommendedSupplements: [
      { item: '2 Boiled Eggs from College Gate / Canteen', cost: 14, protein: 13, note: 'Boiled right in front of you; 13g clean protein.' },
      { item: 'Roasted Chana (40g)', cost: 7, protein: 9, note: 'Keep a 500g jar in your dorm room.' }
    ],
    totalExtraCost: 14,
    boostedProtein: '22g total'
  },
  {
    day: 'Tuesday',
    messMeal: 'Lunch: Watery Arhar Dal, Rice, Aloo Gobhi',
    messRating: 'Moderate Carbs (80g), Low Protein (8g)',
    actionPlan: 'Take 2 ladles of dal (settled bottom portion for thick lentils) + 1 cup rice. Avoid oily sabzi gravy.',
    recommendedSupplements: [
      { item: 'Amul / Mother Dairy Masti Dahi (200g)', cost: 16, protein: 7, note: 'Probiotics soothe hostel digestion and add 7g casein protein.' },
      { item: 'Kettle Boiled Soya Chunks (40g)', cost: 6, protein: 21, note: 'Boil with salt and chaat masala in your room kettle.' }
    ],
    totalExtraCost: 22,
    boostedProtein: '36g total'
  },
  {
    day: 'Wednesday',
    messMeal: 'Dinner: Oily Paneer/Kofta Gravy & 4 Rotis',
    messRating: 'High Oil, Sparse Paneer Cubes (9g)',
    actionPlan: 'Take 3 dry rotis from the counter. Ask server for raw onion/cucumber salad.',
    recommendedSupplements: [
      { item: '3 Boiled Egg Whites or 2 Whole Eggs', cost: 14, protein: 13, note: 'High biological value protein to counter mess grease.' },
      { item: 'Sattu Drink (40g powder with water)', cost: 8, protein: 10, note: 'Mix in hostel tumbler with pinch of black salt.' }
    ],
    totalExtraCost: 14,
    boostedProtein: '32g total'
  },
  {
    day: 'Thursday',
    messMeal: 'Breakfast: Aloo Paratha with Pickle',
    messRating: 'High Carb / Trans Fats, Low Protein (5g)',
    actionPlan: 'Limit to 1 Paratha without extra butter; ask for plain curd if available.',
    recommendedSupplements: [
      { item: 'Sprouted Moong (Self-Sprouted in Dorm)', cost: 6, protein: 12, note: 'Soak green moong in a bowl overnight, wrap in damp towel.' },
      { item: '2 Boiled Eggs', cost: 14, protein: 13, note: 'Instant muscle-building breakfast.' }
    ],
    totalExtraCost: 20,
    boostedProtein: '30g total'
  },
  {
    day: 'Friday',
    messMeal: 'Lunch: Rajma Chawal & Boondi Raita',
    messRating: 'Decent Protein (16g), High Starch',
    actionPlan: 'Excellent mess day! Take double scoop rajma with moderate rice.',
    recommendedSupplements: [
      { item: 'Roasted Peanuts (30g)', cost: 5, protein: 8, note: 'Add healthy fats and zinc.' }
    ],
    totalExtraCost: 5,
    boostedProtein: '24g total'
  },
  {
    day: 'Saturday',
    messMeal: 'Dinner: Khichdi or Mixed Veg & Roti',
    messRating: 'Light on Stomach, Low Protein (10g)',
    actionPlan: 'Eat 1 bowl khichdi or 3 rotis with dry veg.',
    recommendedSupplements: [
      { item: 'Soya Bhurji (Cooked in induction 5 mins)', cost: 12, protein: 26, note: '50g soya granules + 1 onion sautéed in dorm pan.' }
    ],
    totalExtraCost: 12,
    boostedProtein: '36g total'
  },
  {
    day: 'Sunday',
    messMeal: 'Special Dinner (Mess Chicken / Paneer)',
    messRating: 'Good Protein if Non-Veg (25g), Moderate for Veg',
    actionPlan: 'Get your full allocation of chicken or paneer pieces. Skip deep-fried gulab jamun.',
    recommendedSupplements: [
      { item: 'Buttermilk (Chaas 200ml)', cost: 10, protein: 4, note: 'Aids heavy meal digestion.' }
    ],
    totalExtraCost: 10,
    boostedProtein: '29g total'
  }
];

module.exports = { HOSTEL_MESS_GUIDE };
