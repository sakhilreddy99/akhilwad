/**
 * Comprehensive Dataset of 50 Student-Friendly Indian Staple Meals
 * Realistic 2026 Indian market prices, macros, and hostel-friendly prep steps.
 */

const SEED_RECIPES = [
  // ==================== BREAKFAST (1-13) ====================
  {
    id: 1,
    name: 'Egg Bhurji & 2 Whole Wheat Rotis',
    meal_type: 'breakfast',
    diet_type: 'non-veg',
    calories: 420,
    protein: 22,
    carbs: 45,
    fats: 16,
    cost: 35,
    prep_time: 12,
    primary_protein: 'egg',
    is_hostel_friendly: 1,
    tags: ['high-protein', 'muscle-gain', 'staple'],
    ingredients: [
      { name: 'Eggs (2 pcs)', qty: '2 pcs', cost: 14 },
      { name: 'Whole Wheat Flour (for 2 Rotis)', qty: '60g', cost: 3 },
      { name: 'Onion & Tomato Chopped', qty: '80g', cost: 6 },
      { name: 'Green Chilli, Spices & Salt', qty: '1 serving', cost: 2 },
      { name: 'Mustard / Refined Oil', qty: '10ml', cost: 2 }
    ],
    instructions: [
      'Whisk 2 eggs in a bowl with turmeric, salt, and chilli powder.',
      'Heat 1 tsp oil in a pan or induction cooker; sauté diced onion and tomato for 2 mins.',
      'Pour whisked eggs, scramble continuously for 2-3 minutes until soft and fluffy.',
      'Serve hot with 2 fresh rotis (or whole wheat toast).'
    ]
  },
  {
    id: 2,
    name: 'Sprouted Moong Salad & Roasted Peanuts',
    meal_type: 'breakfast',
    diet_type: 'vegan',
    calories: 340,
    protein: 19,
    carbs: 42,
    fats: 11,
    cost: 25,
    prep_time: 5,
    primary_protein: 'sprouts',
    is_hostel_friendly: 1,
    tags: ['vegan', 'no-cook', 'weight-loss', 'fiber-rich'],
    ingredients: [
      { name: 'Sprouted Green Moong', qty: '120g', cost: 14 },
      { name: 'Roasted Peanuts', qty: '25g', cost: 4 },
      { name: 'Onion, Tomato & Cucumber Diced', qty: '80g', cost: 5 },
      { name: 'Lemon Juice & Chaat Masala', qty: '1 serving', cost: 2 }
    ],
    instructions: [
      'Take sprouted moong in a dorm bowl.',
      'Add chopped onion, tomato, roasted crunchy peanuts, and cucumber.',
      'Sprinkle chaat masala, squeeze half a fresh lemon, mix well and enjoy no-cook nutrition.'
    ]
  },
  {
    id: 3,
    name: 'Besan Chilla with Fresh Curd',
    meal_type: 'breakfast',
    diet_type: 'veg',
    calories: 360,
    protein: 17,
    carbs: 44,
    fats: 12,
    cost: 28,
    prep_time: 10,
    primary_protein: 'besan',
    is_hostel_friendly: 1,
    tags: ['veg', 'quick', 'high-protein'],
    ingredients: [
      { name: 'Besan (Gram Flour)', qty: '70g', cost: 7 },
      { name: 'Fresh Curd / Dahi', qty: '100g', cost: 9 },
      { name: 'Chopped Onion, Chilli & Ajwain', qty: '40g', cost: 4 },
      { name: 'Oil & Spices', qty: '1 serving', cost: 8 }
    ],
    instructions: [
      'Mix besan, water, chopped onions, green chilli, and ajwain into a smooth batter.',
      'Pour ladleful onto greased non-stick tawa or induction pan.',
      'Cook 2 minutes per side until golden brown.',
      'Serve warm with a cup of cool curd.'
    ]
  },
  {
    id: 4,
    name: 'Peanut Butter Toast & 1 Ripe Banana',
    meal_type: 'breakfast',
    diet_type: 'vegan',
    calories: 390,
    protein: 13,
    carbs: 56,
    fats: 15,
    cost: 26,
    prep_time: 3,
    primary_protein: 'peanuts',
    is_hostel_friendly: 1,
    tags: ['vegan', 'instant', 'pre-workout'],
    ingredients: [
      { name: 'Whole Wheat Bread (3 Slices)', qty: '3 slices', cost: 9 },
      { name: 'Natural Peanut Butter', qty: '35g', cost: 12 },
      { name: 'Fresh Banana', qty: '1 large', cost: 5 }
    ],
    instructions: [
      'Toast or air-dry 3 whole wheat bread slices.',
      'Spread peanut butter generously across slices.',
      'Top with banana slices; eat immediately for clean instant morning energy.'
    ]
  },
  {
    id: 5,
    name: 'Masala Oats with Boiled Egg',
    meal_type: 'breakfast',
    diet_type: 'non-veg',
    calories: 380,
    protein: 18,
    carbs: 50,
    fats: 11,
    cost: 30,
    prep_time: 8,
    primary_protein: 'egg',
    is_hostel_friendly: 1,
    tags: ['kettle-friendly', 'high-fiber', 'high-protein'],
    ingredients: [
      { name: 'Rolled / Instant Oats', qty: '50g', cost: 13 },
      { name: 'Boiled Egg', qty: '1 pc', cost: 7 },
      { name: 'Veggies (Peas, Carrot, Onion)', qty: '50g', cost: 6 },
      { name: 'Maggi Masala-e-Magic / Spices', qty: '1 sachet', cost: 4 }
    ],
    instructions: [
      'Boil water in electric kettle or single pan.',
      'Add oats, pinch of salt, veggies, and masala seasoning. Simmer 4 mins.',
      'Serve with sliced boiled egg on top.'
    ]
  },
  {
    id: 6,
    name: 'Paneer Bhurji & 2 Whole Wheat Rotis',
    meal_type: 'breakfast',
    diet_type: 'veg',
    calories: 450,
    protein: 24,
    carbs: 40,
    fats: 20,
    cost: 42,
    prep_time: 12,
    primary_protein: 'paneer',
    is_hostel_friendly: 1,
    tags: ['high-protein', 'veg', 'muscle-gain'],
    ingredients: [
      { name: 'Fresh Paneer Crumbled', qty: '80g', cost: 30 },
      { name: 'Whole Wheat Flour (2 Rotis)', qty: '60g', cost: 3 },
      { name: 'Onion, Tomato, Spices & Oil', qty: '1 serving', cost: 9 }
    ],
    instructions: [
      'Sauté onions, tomatoes, and green chillies in 1 tsp oil.',
      'Add turmeric, garam masala, and crumbled paneer.',
      'Toss on high heat for 3 minutes without overcooking.',
      'Serve hot with 2 soft wheat rotis.'
    ]
  },
  {
    id: 7,
    name: 'Sattu Drink & Roasted Chana with Lemon',
    meal_type: 'breakfast',
    diet_type: 'vegan',
    calories: 310,
    protein: 20,
    carbs: 45,
    fats: 6,
    cost: 22,
    prep_time: 4,
    primary_protein: 'sattu',
    is_hostel_friendly: 1,
    tags: ['vegan', 'superfood', 'pocket-friendly', 'gut-healthy'],
    ingredients: [
      { name: 'Roasted Bengal Gram Sattu', qty: '50g', cost: 10 },
      { name: 'Roasted Chana (Snack side)', qty: '30g', cost: 6 },
      { name: 'Black Salt, Jeera & Lemon', qty: '1 serving', cost: 3 },
      { name: 'Chilled Water & Mint', qty: '300ml', cost: 3 }
    ],
    instructions: [
      'Add sattu powder to a glass of cold water; whisk out any lumps.',
      'Season with roasted cumin powder, black salt, and fresh lemon juice.',
      'Drink fresh alongside 30g roasted crunchy chana for 20g natural protein under ₹22.'
    ]
  },
  {
    id: 8,
    name: 'Peanut Vegetable Poha with Lemon',
    meal_type: 'breakfast',
    diet_type: 'vegan',
    calories: 340,
    protein: 10,
    carbs: 56,
    fats: 9,
    cost: 22,
    prep_time: 10,
    primary_protein: 'peanuts',
    is_hostel_friendly: 1,
    tags: ['vegan', 'staple', 'light'],
    ingredients: [
      { name: 'Poha (Flattened Rice)', qty: '75g', cost: 6 },
      { name: 'Peanuts Roasted', qty: '30g', cost: 6 },
      { name: 'Onion, Green Chilli & Mustard Seeds', qty: '50g', cost: 6 },
      { name: 'Oil & Lemon Juice', qty: '1 serving', cost: 4 }
    ],
    instructions: [
      'Rinse poha in a strainer and drain water completely.',
      'Temper mustard seeds, onions, curry leaves, and crunchy peanuts in hot oil.',
      'Add turmeric and salt, toss poha gently, cover for 2 minutes.',
      'Garnish with lemon juice.'
    ]
  },
  {
    id: 9,
    name: '3 Boiled Eggs & Whole Wheat Toast',
    meal_type: 'breakfast',
    diet_type: 'non-veg',
    calories: 360,
    protein: 23,
    carbs: 28,
    fats: 15,
    cost: 29,
    prep_time: 10,
    primary_protein: 'egg',
    is_hostel_friendly: 1,
    tags: ['high-protein', 'low-carb', 'gym-staple'],
    ingredients: [
      { name: 'Eggs (3 Whole Eggs)', qty: '3 pcs', cost: 21 },
      { name: 'Whole Wheat Bread (2 slices)', qty: '2 slices', cost: 6 },
      { name: 'Black Pepper & Salt', qty: '1 pinch', cost: 2 }
    ],
    instructions: [
      'Boil 3 eggs in kettle or pot for 9-10 minutes.',
      'Peel and halve eggs, sprinkle freshly ground black pepper.',
      'Pair with toasted whole wheat bread.'
    ]
  },
  {
    id: 10,
    name: 'Vegetable Sooji Upma with Peanuts',
    meal_type: 'breakfast',
    diet_type: 'vegan',
    calories: 320,
    protein: 9,
    carbs: 52,
    fats: 9,
    cost: 20,
    prep_time: 12,
    primary_protein: 'sooji',
    is_hostel_friendly: 1,
    tags: ['vegan', 'economical', 'digestive'],
    ingredients: [
      { name: 'Semolina (Sooji)', qty: '65g', cost: 5 },
      { name: 'Roasted Peanuts', qty: '25g', cost: 5 },
      { name: 'Mixed Veggies & Curry leaves', qty: '60g', cost: 6 },
      { name: 'Mustard seeds & Oil', qty: '1 serving', cost: 4 }
    ],
    instructions: [
      'Dry roast sooji for 3 mins until fragrant and keep aside.',
      'Heat oil, crackle mustard seeds, peanuts, and sauté vegetables.',
      'Add 2 cups boiling water with salt, gradually stir in sooji to avoid lumps.',
      'Cover on low heat for 3 minutes until fluffy.'
    ]
  },
  {
    id: 11,
    name: 'Curd Oats with Chia & Apple Slices',
    meal_type: 'breakfast',
    diet_type: 'veg',
    calories: 340,
    protein: 15,
    carbs: 48,
    fats: 9,
    cost: 32,
    prep_time: 4,
    primary_protein: 'curd',
    is_hostel_friendly: 1,
    tags: ['veg', 'overnight-prep', 'gut-health'],
    ingredients: [
      { name: 'Rolled Oats', qty: '50g', cost: 13 },
      { name: 'Fresh Dahi (Curd)', qty: '150g', cost: 12 },
      { name: 'Half Apple Diced', qty: '60g', cost: 5 },
      { name: 'Pinch of Cinnamon / Chia', qty: '1 serving', cost: 2 }
    ],
    instructions: [
      'Mix oats with chilled curd in a lunchbox or dorm mason jar.',
      'Let sit for 20 mins (or overnight in hostel fridge/cool corner).',
      'Top with diced apple and cinnamon for a refreshing, probiotic meal.'
    ]
  },
  {
    id: 12,
    name: 'Sweet Potato Chaat with Boiled Chickpeas',
    meal_type: 'breakfast',
    diet_type: 'vegan',
    calories: 330,
    protein: 12,
    carbs: 60,
    fats: 4,
    cost: 24,
    prep_time: 8,
    primary_protein: 'chickpea',
    is_hostel_friendly: 1,
    tags: ['vegan', 'complex-carbs', 'stamina'],
    ingredients: [
      { name: 'Boiled Sweet Potato', qty: '150g', cost: 10 },
      { name: 'Boiled White / Black Chana', qty: '60g', cost: 8 },
      { name: 'Chaat Masala, Lemon & Green Chilli', qty: '1 serving', cost: 6 }
    ],
    instructions: [
      'Chop boiled sweet potato into cubes.',
      'Toss with boiled chickpeas, diced green chillies, lemon, and chaat masala.',
      'Sustained release energy ideal for exams or long lectures.'
    ]
  },
  {
    id: 13,
    name: 'Tofu Bhurji Toast',
    meal_type: 'breakfast',
    diet_type: 'vegan',
    calories: 370,
    protein: 21,
    carbs: 42,
    fats: 13,
    cost: 36,
    prep_time: 10,
    primary_protein: 'tofu',
    is_hostel_friendly: 1,
    tags: ['vegan', 'high-protein', 'dairy-free'],
    ingredients: [
      { name: 'Tofu (Crumbled)', qty: '100g', cost: 24 },
      { name: 'Whole Wheat Bread', qty: '2 slices', cost: 6 },
      { name: 'Onion, Tomato, Turmeric & Oil', qty: '1 serving', cost: 6 }
    ],
    instructions: [
      'Heat oil; cook onion and tomatoes with turmeric and red chilli powder.',
      'Add crumbled tofu, cook for 3 minutes.',
      'Serve warm on toasted bread.'
    ]
  },

  // ==================== LUNCH (14-27) ====================
  {
    id: 14,
    name: 'Soya Chunks Curry & Steamed Rice',
    meal_type: 'lunch',
    diet_type: 'vegan',
    calories: 620,
    protein: 36,
    carbs: 85,
    fats: 12,
    cost: 40,
    prep_time: 18,
    primary_protein: 'soya',
    is_hostel_friendly: 1,
    tags: ['super-protein', 'muscle-gain', 'budget-hero'],
    ingredients: [
      { name: 'Soya Chunks (Dry)', qty: '60g', cost: 9 },
      { name: 'White Rice (Raw)', qty: '90g', cost: 6 },
      { name: 'Onion & Tomato Gravy Base', qty: '120g', cost: 12 },
      { name: 'Spices, Ginger-Garlic & Oil', qty: '1 serving', cost: 13 }
    ],
    instructions: [
      'Boil soya chunks in salted water for 5 minutes; squeeze out water thoroughly.',
      'Cook rice in electric cooker or kettle.',
      'In a pan, fry onion paste, ginger-garlic, tomato puree, and garam masala until oil separates.',
      'Add soya chunks and 1 cup water; simmer 8 mins. Serve hot over rice.'
    ]
  },
  {
    id: 15,
    name: 'Dal Tadka, Jeera Rice & Cucumber Salad',
    meal_type: 'lunch',
    diet_type: 'veg',
    calories: 550,
    protein: 19,
    carbs: 88,
    fats: 12,
    cost: 35,
    prep_time: 20,
    primary_protein: 'dal',
    is_hostel_friendly: 1,
    tags: ['comfort-food', 'veg', 'staple'],
    ingredients: [
      { name: 'Yellow Toor/Moong Dal', qty: '60g', cost: 10 },
      { name: 'Rice', qty: '85g', cost: 6 },
      { name: 'Ghee/Oil Tadka (Jeera, Garlic, Chilli)', qty: '1 serving', cost: 9 },
      { name: 'Cucumber Slices', qty: '80g', cost: 10 }
    ],
    instructions: [
      'Pressure cook or boil dal with turmeric and salt until tender.',
      'Cook cumin (jeera) scented rice.',
      'Temper dal with hot ghee/oil, garlic slices, dried red chillies, and cumin seeds.',
      'Pair with fresh crisp cucumber salad.'
    ]
  },
  {
    id: 16,
    name: 'Rajma Masala & Steamed Rice',
    meal_type: 'lunch',
    diet_type: 'vegan',
    calories: 590,
    protein: 23,
    carbs: 94,
    fats: 11,
    cost: 38,
    prep_time: 25,
    primary_protein: 'rajma',
    is_hostel_friendly: 1,
    tags: ['vegan', 'classic', 'high-fiber'],
    ingredients: [
      { name: 'Rajma (Kidney Beans)', qty: '70g', cost: 11 },
      { name: 'Steamed Rice', qty: '90g', cost: 6 },
      { name: 'Tomato, Onion, Garam Masala', qty: '1 serving', cost: 14 },
      { name: 'Mustard Oil & Aromatics', qty: '1 serving', cost: 7 }
    ],
    instructions: [
      'Boil pre-soaked rajma until tender.',
      'Sauté spiced onion-tomato curry base until rich red.',
      'Mash a few beans into the gravy to thicken; simmer together for 10 minutes.',
      'Serve over steaming white or brown rice.'
    ]
  },
  {
    id: 17,
    name: 'Chole (Chickpea Curry) & 3 Whole Wheat Rotis',
    meal_type: 'lunch',
    diet_type: 'vegan',
    calories: 610,
    protein: 23,
    carbs: 88,
    fats: 15,
    cost: 36,
    prep_time: 22,
    primary_protein: 'chickpea',
    is_hostel_friendly: 1,
    tags: ['vegan', 'north-indian', 'high-protein'],
    ingredients: [
      { name: 'Kabuli Chana (Dry)', qty: '65g', cost: 10 },
      { name: 'Whole Wheat Atta (for 3 Rotis)', qty: '85g', cost: 5 },
      { name: 'Chole Masala, Onion & Tomato', qty: '1 serving', cost: 15 },
      { name: 'Oil & Green Coriander', qty: '1 serving', cost: 6 }
    ],
    instructions: [
      'Cook soaked chickpeas until butter-soft.',
      'Prepare thick masala gravy with chole spices and onions.',
      'Simmer chole in gravy for 10 minutes.',
      'Serve with 3 fresh hot rotis.'
    ]
  },
  {
    id: 18,
    name: 'Egg Curry (2 Eggs) & Steamed Rice',
    meal_type: 'lunch',
    diet_type: 'non-veg',
    calories: 570,
    protein: 24,
    carbs: 78,
    fats: 17,
    cost: 42,
    prep_time: 15,
    primary_protein: 'egg',
    is_hostel_friendly: 1,
    tags: ['non-veg', 'muscle-gain', 'hostel-favorite'],
    ingredients: [
      { name: 'Boiled Eggs (2 pcs)', qty: '2 pcs', cost: 14 },
      { name: 'Steamed White Rice', qty: '85g', cost: 6 },
      { name: 'Onion, Tomato, Ginger-Garlic Paste', qty: '1 serving', cost: 14 },
      { name: 'Oil & Spices', qty: '1 serving', cost: 8 }
    ],
    instructions: [
      'Prick boiled eggs with fork and shallow fry in oil with turmeric until golden.',
      'Make fragrant spiced tomato-onion curry gravy.',
      'Drop eggs into gravy, simmer 5 minutes so flavours penetrate.',
      'Serve hot with rice.'
    ]
  },
  {
    id: 19,
    name: 'Kala Chana Curry & 3 Whole Wheat Rotis',
    meal_type: 'lunch',
    diet_type: 'vegan',
    calories: 540,
    protein: 21,
    carbs: 84,
    fats: 10,
    cost: 32,
    prep_time: 20,
    primary_protein: 'chickpea',
    is_hostel_friendly: 1,
    tags: ['vegan', 'iron-rich', 'super-economical'],
    ingredients: [
      { name: 'Kala Chana (Black Chickpeas)', qty: '65g', cost: 8 },
      { name: 'Whole Wheat Atta (3 Rotis)', qty: '85g', cost: 5 },
      { name: 'Onion, Tomato & Coriander Powder', qty: '1 serving', cost: 12 },
      { name: 'Oil & Seasonings', qty: '1 serving', cost: 7 }
    ],
    instructions: [
      'Boil soaked kala chana with tea bag/cinnamon for dark earthy aroma.',
      'Sauté with roasted cumin and dry masala paste.',
      'Simmer with cooking broth for nutrient retention.',
      'Pair with 3 rotis.'
    ]
  },
  {
    id: 20,
    name: 'Hostel Budget Chicken Curry & Rice',
    meal_type: 'lunch',
    diet_type: 'non-veg',
    calories: 630,
    protein: 35,
    carbs: 74,
    fats: 18,
    cost: 55,
    prep_time: 22,
    primary_protein: 'chicken',
    is_hostel_friendly: 1,
    tags: ['non-veg', 'high-protein', 'weekend-special'],
    ingredients: [
      { name: 'Fresh Chicken Cuts (Bone-in)', qty: '110g', cost: 30 },
      { name: 'Steamed Rice', qty: '85g', cost: 6 },
      { name: 'Onion-Garlic Curry Base', qty: '1 serving', cost: 13 },
      { name: 'Spices & Mustard Oil', qty: '1 serving', cost: 6 }
    ],
    instructions: [
      'Marinate chicken in turmeric, curd, and salt for 10 mins.',
      'Sear chicken in hot mustard oil with whole cloves and cardamom.',
      'Add onion gravy and water; simmer 15 mins until chicken is juicy.',
      'Serve over rice.'
    ]
  },
  {
    id: 21,
    name: 'Palak Paneer & 2 Whole Wheat Rotis',
    meal_type: 'lunch',
    diet_type: 'veg',
    calories: 560,
    protein: 23,
    carbs: 52,
    fats: 26,
    cost: 48,
    prep_time: 18,
    primary_protein: 'paneer',
    is_hostel_friendly: 1,
    tags: ['veg', 'iron-rich', 'calcium-rich'],
    ingredients: [
      { name: 'Paneer Cubes', qty: '75g', cost: 28 },
      { name: 'Fresh Palak (Spinach Puree)', qty: '150g', cost: 7 },
      { name: 'Atta (for 2 Rotis)', qty: '60g', cost: 3 },
      { name: 'Garlic, Cream/Milk & Spices', qty: '1 serving', cost: 10 }
    ],
    instructions: [
      'Blanch spinach in boiling water for 2 mins, shock in cold water and blend.',
      'Sauté minced garlic in 1 tsp oil, add spices and spinach puree.',
      'Toss in raw paneer cubes, simmer gently for 4 mins.',
      'Serve with warm rotis.'
    ]
  },
  {
    id: 22,
    name: 'Moong Dal Khichdi with Curd & Pickle',
    meal_type: 'lunch',
    diet_type: 'veg',
    calories: 510,
    protein: 18,
    carbs: 80,
    fats: 11,
    cost: 30,
    prep_time: 15,
    primary_protein: 'dal',
    is_hostel_friendly: 1,
    tags: ['one-pot', 'kettle-friendly', 'recovery-meal'],
    ingredients: [
      { name: 'Moong Dal & Rice (Equal Blend)', qty: '110g', cost: 12 },
      { name: 'Fresh Dahi (Curd)', qty: '120g', cost: 10 },
      { name: 'Turmeric, Salt, Ghee & Jeera', qty: '1 serving', cost: 8 }
    ],
    instructions: [
      'Rinse dal and rice together.',
      'Cook in 3.5x water with turmeric and salt in electric kettle or cooker until porridge-like.',
      'Top with a drop of ghee and enjoy with cold curd.'
    ]
  },
  {
    id: 23,
    name: 'Mixed Veg Soya Pulao with Mint Curd',
    meal_type: 'lunch',
    diet_type: 'veg',
    calories: 570,
    protein: 28,
    carbs: 76,
    fats: 14,
    cost: 38,
    prep_time: 18,
    primary_protein: 'soya',
    is_hostel_friendly: 1,
    tags: ['one-pot', 'high-protein', 'hostel-friendly'],
    ingredients: [
      { name: 'Soya Chunks', qty: '45g', cost: 7 },
      { name: 'Basmati/Regular Rice', qty: '80g', cost: 6 },
      { name: 'Curd & Mint Raita', qty: '100g', cost: 9 },
      { name: 'Veggies, Biryani Spices & Oil', qty: '1 serving', cost: 16 }
    ],
    instructions: [
      'Soak soya chunks in warm water for 5 minutes, squeeze dry.',
      'Sauté onions, carrots, peas, and soya with pulao garam masala.',
      'Add rice and 2x water; cook covered until rice is fragrant and fluffy.',
      'Serve with mint curd.'
    ]
  },
  {
    id: 24,
    name: 'Black Eyed Peas (Lobia) Masala & Rice',
    meal_type: 'lunch',
    diet_type: 'vegan',
    calories: 530,
    protein: 20,
    carbs: 84,
    fats: 9,
    cost: 34,
    prep_time: 18,
    primary_protein: 'lobia',
    is_hostel_friendly: 1,
    tags: ['vegan', 'fiber-rich', 'budget'],
    ingredients: [
      { name: 'Lobia (Cowpeas)', qty: '60g', cost: 8 },
      { name: 'White Rice', qty: '85g', cost: 6 },
      { name: 'Tomato-Onion Masala', qty: '1 serving', cost: 14 },
      { name: 'Cooking Oil & Spices', qty: '1 serving', cost: 6 }
    ],
    instructions: [
      'Boil lobia until soft (lobia cooks in 12 mins without long soaking).',
      'Cook spicy tomato-garlic masala.',
      'Combine and simmer 7 mins to absorb gravy.',
      'Pair with steamed white rice.'
    ]
  },
  {
    id: 25,
    name: 'Masoor Dal (Red Lentil) & 3 Whole Wheat Rotis',
    meal_type: 'lunch',
    diet_type: 'vegan',
    calories: 490,
    protein: 20,
    carbs: 78,
    fats: 8,
    cost: 28,
    prep_time: 15,
    primary_protein: 'dal',
    is_hostel_friendly: 1,
    tags: ['fast-cooking', 'vegan', 'iron-rich'],
    ingredients: [
      { name: 'Dhuli Masoor Dal', qty: '65g', cost: 8 },
      { name: 'Atta (for 3 Rotis)', qty: '85g', cost: 5 },
      { name: 'Tomato, Garlic, Mustard Oil Tadka', qty: '1 serving', cost: 11 },
      { name: 'Spices & Coriander', qty: '1 serving', cost: 4 }
    ],
    instructions: [
      'Masoor dal cooks in just 10 mins in an open pan or electric kettle.',
      'Prepare garlic and tomato tadka with mustard oil.',
      'Mix tadka into soupy dal.',
      'Eat with 3 warm rotis.'
    ]
  },
  {
    id: 26,
    name: 'Tofu Bhurji Curry & 3 Whole Wheat Rotis',
    meal_type: 'lunch',
    diet_type: 'vegan',
    calories: 510,
    protein: 27,
    carbs: 58,
    fats: 16,
    cost: 45,
    prep_time: 15,
    primary_protein: 'tofu',
    is_hostel_friendly: 1,
    tags: ['vegan', 'high-protein', 'dairy-free'],
    ingredients: [
      { name: 'Firm Tofu (Soy)', qty: '120g', cost: 28 },
      { name: 'Atta (3 Rotis)', qty: '85g', cost: 5 },
      { name: 'Onion, Tomato & Bell Pepper', qty: '80g', cost: 7 },
      { name: 'Spices & Oil', qty: '1 serving', cost: 5 }
    ],
    instructions: [
      'Sauté bell peppers, onions, and tomatoes.',
      'Crumble in firm tofu with cumin, coriander, and chili powder.',
      'Stir fry 4 minutes.',
      'Serve alongside fresh rotis.'
    ]
  },
  {
    id: 27,
    name: 'Affordable Fish Curry & Rice',
    meal_type: 'lunch',
    diet_type: 'non-veg',
    calories: 580,
    protein: 30,
    carbs: 72,
    fats: 15,
    cost: 52,
    prep_time: 20,
    primary_protein: 'fish',
    is_hostel_friendly: 0,
    tags: ['non-veg', 'omega-3', 'high-protein'],
    ingredients: [
      { name: 'Rohu/Katla Fish Steak', qty: '120g', cost: 32 },
      { name: 'White Rice', qty: '85g', cost: 6 },
      { name: 'Mustard/Tomato Curry Paste', qty: '1 serving', cost: 10 },
      { name: 'Mustard Oil & Panch Phoron', qty: '1 serving', cost: 4 }
    ],
    instructions: [
      'Rub fish lightly with turmeric and salt; shallow fry 2 mins each side.',
      'Prepare light mustard-tomato gravy with green chillies.',
      'Drop fish into simmering sauce for 5 mins.',
      'Serve with steamed white rice.'
    ]
  },

  // ==================== SNACKS (28-38) ====================
  {
    id: 28,
    name: 'Roasted Chana (50g) & Masala Tea',
    meal_type: 'snack',
    diet_type: 'veg',
    calories: 210,
    protein: 11,
    carbs: 30,
    fats: 4,
    cost: 15,
    prep_time: 5,
    primary_protein: 'chana',
    is_hostel_friendly: 1,
    tags: ['pocket-friendly', 'instant', 'high-fiber'],
    ingredients: [
      { name: 'Roasted Bengal Gram (Bhuna Chana)', qty: '50g', cost: 8 },
      { name: 'Chai (Milk, Tea Leaves, Ginger)', qty: '1 cup', cost: 6 },
      { name: 'Black Salt / Pepper', qty: '1 pinch', cost: 1 }
    ],
    instructions: [
      'Brew quick hot ginger tea in kettle with splash of milk.',
      'Munch alongside crisp roasted salted chana for 11g clean protein.'
    ]
  },
  {
    id: 29,
    name: 'Sprouted Moong Bhel with Lemon',
    meal_type: 'snack',
    diet_type: 'vegan',
    calories: 190,
    protein: 10,
    carbs: 32,
    fats: 2,
    cost: 18,
    prep_time: 3,
    primary_protein: 'sprouts',
    is_hostel_friendly: 1,
    tags: ['vegan', 'low-fat', 'no-cook'],
    ingredients: [
      { name: 'Sprouted Green Moong', qty: '75g', cost: 9 },
      { name: 'Murmura (Puffed Rice)', qty: '20g', cost: 2 },
      { name: 'Tomato, Onion, Lemon & Chaat Masala', qty: '1 serving', cost: 7 }
    ],
    instructions: [
      'Mix sprouted moong, puffed rice, finely chopped onions and tomatoes.',
      'Sprinkle spicy chaat masala and fresh lemon juice.',
      'Zero cooking needed, instant crunchy dorm snack.'
    ]
  },
  {
    id: 30,
    name: '2 Hard Boiled Eggs with Chaat Masala',
    meal_type: 'snack',
    diet_type: 'non-veg',
    calories: 155,
    protein: 13,
    carbs: 1,
    fats: 11,
    cost: 16,
    prep_time: 8,
    primary_protein: 'egg',
    is_hostel_friendly: 1,
    tags: ['keto-friendly', 'pure-protein', 'kettle-friendly'],
    ingredients: [
      { name: 'Whole Eggs (2 pcs)', qty: '2 pcs', cost: 14 },
      { name: 'Chaat Masala & Pepper', qty: '1 pinch', cost: 2 }
    ],
    instructions: [
      'Boil 2 eggs in electric kettle for 8 minutes.',
      'Peel, slice and sprinkle chaat masala.',
      'Instant 13g bioavailable protein for ₹16.'
    ]
  },
  {
    id: 31,
    name: 'Peanut Jaggery Chikki & Black Coffee',
    meal_type: 'snack',
    diet_type: 'vegan',
    calories: 220,
    protein: 7,
    carbs: 26,
    fats: 10,
    cost: 14,
    prep_time: 2,
    primary_protein: 'peanuts',
    is_hostel_friendly: 1,
    tags: ['energy-boost', 'sweet-tooth', 'instant'],
    ingredients: [
      { name: 'Peanut Chikki Bar', qty: '40g', cost: 10 },
      { name: 'Instant Coffee & Warm Water', qty: '1 mug', cost: 4 }
    ],
    instructions: [
      'Dissolve instant coffee powder in hot water from kettle.',
      'Pair with crunchy peanut jaggery bar for studying energy.'
    ]
  },
  {
    id: 32,
    name: 'Roasted Makhana (Foxnuts) with Rock Salt',
    meal_type: 'snack',
    diet_type: 'vegan',
    calories: 170,
    protein: 5,
    carbs: 28,
    fats: 4,
    cost: 22,
    prep_time: 5,
    primary_protein: 'makhana',
    is_hostel_friendly: 1,
    tags: ['low-calorie', 'antioxidants', 'gluten-free'],
    ingredients: [
      { name: 'Makhana (Phool Makhana)', qty: '30g', cost: 18 },
      { name: 'Ghee/Oil & Rock Salt', qty: '1 serving', cost: 4 }
    ],
    instructions: [
      'Roast makhana in pan with 1/2 tsp ghee until crispy and crunchy.',
      'Season with rock salt, black pepper, or peri-peri powder.'
    ]
  },
  {
    id: 33,
    name: 'Roasted Peanuts with Skin (40g)',
    meal_type: 'snack',
    diet_type: 'vegan',
    calories: 230,
    protein: 10,
    carbs: 8,
    fats: 18,
    cost: 12,
    prep_time: 1,
    primary_protein: 'peanuts',
    is_hostel_friendly: 1,
    tags: ['vegan', 'healthy-fats', 'cheapest-protein'],
    ingredients: [
      { name: 'Roasted Shelled Peanuts', qty: '40g', cost: 10 },
      { name: 'Salt', qty: '1 pinch', cost: 2 }
    ],
    instructions: [
      'Pre-pack 40g roasted peanuts in a pouch.',
      'Eat directly during study intervals.'
    ]
  },
  {
    id: 34,
    name: 'Fresh Curd (150g) with Honey & Sunflower Seeds',
    meal_type: 'snack',
    diet_type: 'veg',
    calories: 180,
    protein: 9,
    carbs: 18,
    fats: 7,
    cost: 20,
    prep_time: 2,
    primary_protein: 'curd',
    is_hostel_friendly: 1,
    tags: ['probiotic', 'cooling', 'digestive'],
    ingredients: [
      { name: 'Fresh Dahi', qty: '150g', cost: 12 },
      { name: 'Honey', qty: '1 tsp', cost: 5 },
      { name: 'Seeds / Roasted Chana', qty: '15g', cost: 3 }
    ],
    instructions: [
      'Whisk curd in a glass bowl.',
      'Drizzle with honey and top with crunch seeds.'
    ]
  },
  {
    id: 35,
    name: 'Sweet Corn Chaat with Green Chillies & Lime',
    meal_type: 'snack',
    diet_type: 'vegan',
    calories: 190,
    protein: 6,
    carbs: 38,
    fats: 2,
    cost: 18,
    prep_time: 5,
    primary_protein: 'corn',
    is_hostel_friendly: 1,
    tags: ['vegan', 'kettle-friendly', 'juicy'],
    ingredients: [
      { name: 'Sweet Corn Kernels', qty: '120g', cost: 12 },
      { name: 'Butter/Oil, Green Chilli & Lemon', qty: '1 serving', cost: 6 }
    ],
    instructions: [
      'Boil corn in kettle for 3 minutes.',
      'Drain water, add touch of butter, finely chopped green chilli, chaat masala and lime.'
    ]
  },
  {
    id: 36,
    name: 'Sattu Namkeen Cooler (Savory Protein Shake)',
    meal_type: 'snack',
    diet_type: 'vegan',
    calories: 160,
    protein: 10,
    carbs: 24,
    fats: 2,
    cost: 12,
    prep_time: 2,
    primary_protein: 'sattu',
    is_hostel_friendly: 1,
    tags: ['desi-protein-shake', 'summer-cool', 'vegan'],
    ingredients: [
      { name: 'Chana Sattu Powder', qty: '30g', cost: 6 },
      { name: 'Black Salt, Roasted Jeera, Green Chilli, Lemon', qty: '1 serving', cost: 6 }
    ],
    instructions: [
      'Shake 2 tbsp sattu in shaker bottle with 250ml cold water.',
      'Add lemon juice, black salt, and jeera powder for instant natural protein shake.'
    ]
  },
  {
    id: 37,
    name: 'Crispy Pan-Roasted Soya Chunks Snack',
    meal_type: 'snack',
    diet_type: 'vegan',
    calories: 180,
    protein: 18,
    carbs: 14,
    fats: 3,
    cost: 15,
    prep_time: 8,
    primary_protein: 'soya',
    is_hostel_friendly: 1,
    tags: ['massive-protein', 'crunchy', 'vegan'],
    ingredients: [
      { name: 'Mini Soya Chunks', qty: '35g', cost: 5 },
      { name: 'Chilli Powder, Chaat Masala & Oil Spray', qty: '1 serving', cost: 10 }
    ],
    instructions: [
      'Soak soya chunks 3 mins in hot water, squeeze bone dry.',
      'Pan fry with 1/2 tsp oil and chaat masala until crispy brown.',
      'Delivers an incredible 18g protein for ₹15.'
    ]
  },
  {
    id: 38,
    name: 'Masala Buttermilk (Chaas) & 1 Banana',
    meal_type: 'snack',
    diet_type: 'veg',
    calories: 160,
    protein: 6,
    carbs: 30,
    fats: 2,
    cost: 14,
    prep_time: 2,
    primary_protein: 'curd',
    is_hostel_friendly: 1,
    tags: ['electrolytes', 'refreshing', 'low-cost'],
    ingredients: [
      { name: 'Spiced Buttermilk (Amul / Mother Dairy packet)', qty: '200ml', cost: 9 },
      { name: 'Fresh Banana', qty: '1 pc', cost: 5 }
    ],
    instructions: [
      'Drink chilled packaged chaas alongside 1 ripe banana for quick electrolyte balance.'
    ]
  },

  // ==================== DINNER (39-50) ====================
  {
    id: 39,
    name: 'Dal Khichdi & Fresh Curd',
    meal_type: 'dinner',
    diet_type: 'veg',
    calories: 520,
    protein: 19,
    carbs: 82,
    fats: 11,
    cost: 30,
    prep_time: 15,
    primary_protein: 'dal',
    is_hostel_friendly: 1,
    tags: ['easy-digest', 'one-pot', 'classic'],
    ingredients: [
      { name: 'Yellow Moong Dal & Rice (Equal Blend)', qty: '100g', cost: 11 },
      { name: 'Fresh Curd', qty: '120g', cost: 10 },
      { name: 'Ghee Tadka (Jeera, Hing, Turmeric)', qty: '1 serving', cost: 9 }
    ],
    instructions: [
      'Wash moong dal and rice; boil with turmeric, salt, and water.',
      'Finish with warm jeera-hing ghee aroma.',
      'Serve alongside fresh curd for calm evening digestion.'
    ]
  },
  {
    id: 40,
    name: 'Soya Matar Curry & 3 Whole Wheat Rotis',
    meal_type: 'dinner',
    diet_type: 'vegan',
    calories: 560,
    protein: 32,
    carbs: 68,
    fats: 14,
    cost: 38,
    prep_time: 18,
    primary_protein: 'soya',
    is_hostel_friendly: 1,
    tags: ['high-protein', 'vegan', 'dorm-dinner'],
    ingredients: [
      { name: 'Soya Chunks', qty: '50g', cost: 7 },
      { name: 'Green Peas (Matar)', qty: '50g', cost: 8 },
      { name: 'Atta (3 Rotis)', qty: '85g', cost: 5 },
      { name: 'Curry Masala & Oil', qty: '1 serving', cost: 18 }
    ],
    instructions: [
      'Hydrate soya chunks and squeeze water.',
      'Sauté peas and soya in rich tomato-onion curry sauce.',
      'Simmer 8 minutes until peas are tender.',
      'Enjoy with 3 whole wheat rotis.'
    ]
  },
  {
    id: 41,
    name: 'Paneer & Shimla Mirch Bhurji with 2 Rotis',
    meal_type: 'dinner',
    diet_type: 'veg',
    calories: 520,
    protein: 22,
    carbs: 48,
    fats: 24,
    cost: 44,
    prep_time: 14,
    primary_protein: 'paneer',
    is_hostel_friendly: 1,
    tags: ['veg', 'low-carb-dinner', 'rich-taste'],
    ingredients: [
      { name: 'Fresh Paneer Crumbled', qty: '80g', cost: 30 },
      { name: 'Capsicum (Shimla Mirch) Sliced', qty: '60g', cost: 5 },
      { name: 'Atta (2 Rotis)', qty: '60g', cost: 3 },
      { name: 'Oil & Spices', qty: '1 serving', cost: 6 }
    ],
    instructions: [
      'Stir fry sliced bell peppers and onions in 1 tsp oil on high heat.',
      'Add crumbled paneer, black pepper, and garam masala; toss for 2 minutes.',
      'Serve with 2 hot rotis.'
    ]
  },
  {
    id: 42,
    name: 'Egg Curry (2 Boiled Eggs) & 3 Rotis',
    meal_type: 'dinner',
    diet_type: 'non-veg',
    calories: 540,
    protein: 23,
    carbs: 66,
    fats: 18,
    cost: 38,
    prep_time: 15,
    primary_protein: 'egg',
    is_hostel_friendly: 1,
    tags: ['non-veg', 'muscle-gain', 'student-staple'],
    ingredients: [
      { name: 'Boiled Eggs (2 pcs)', qty: '2 pcs', cost: 14 },
      { name: 'Atta (3 Rotis)', qty: '85g', cost: 5 },
      { name: 'Spiced Tomato-Onion Gravy', qty: '1 serving', cost: 14 },
      { name: 'Oil & Spices', qty: '1 serving', cost: 5 }
    ],
    instructions: [
      'Sauté spiced gravy until aromatic.',
      'Halve 2 hard-boiled eggs and simmer gently in gravy.',
      'Eat with 3 wheat rotis.'
    ]
  },
  {
    id: 43,
    name: 'Toor Dal, Steamed Rice & Bhindi Fry',
    meal_type: 'dinner',
    diet_type: 'vegan',
    calories: 530,
    protein: 16,
    carbs: 82,
    fats: 13,
    cost: 34,
    prep_time: 20,
    primary_protein: 'dal',
    is_hostel_friendly: 1,
    tags: ['vegan', 'traditional', 'home-style'],
    ingredients: [
      { name: 'Toor Dal', qty: '50g', cost: 8 },
      { name: 'White Rice', qty: '80g', cost: 5 },
      { name: 'Bhindi (Okra) Chopped', qty: '80g', cost: 12 },
      { name: 'Mustard Oil & Spices', qty: '1 serving', cost: 9 }
    ],
    instructions: [
      'Cook toor dal with pinch of turmeric and salt; temper with garlic and jeera.',
      'Stir fry bhindi in a hot pan with dry mango powder (amchur).',
      'Serve hot over steamed rice.'
    ]
  },
  {
    id: 44,
    name: 'Black Chana Soup with 2 Rotis & Salad',
    meal_type: 'dinner',
    diet_type: 'vegan',
    calories: 470,
    protein: 19,
    carbs: 72,
    fats: 9,
    cost: 28,
    prep_time: 18,
    primary_protein: 'chickpea',
    is_hostel_friendly: 1,
    tags: ['vegan', 'light-dinner', 'iron-rich'],
    ingredients: [
      { name: 'Kala Chana', qty: '60g', cost: 7 },
      { name: 'Atta (2 Rotis)', qty: '60g', cost: 3 },
      { name: 'Tomato, Ginger & Black Pepper Broth', qty: '1 serving', cost: 12 },
      { name: 'Salad Greens', qty: '50g', cost: 6 }
    ],
    instructions: [
      'Boil black chana with ginger and crushed black pepper.',
      'Mash some beans to build a hearty, peppery Indian soup.',
      'Pair with 2 warm rotis and sliced salad.'
    ]
  },
  {
    id: 45,
    name: 'Budget Chicken Stir-Fry & 2 Rotis',
    meal_type: 'dinner',
    diet_type: 'non-veg',
    calories: 560,
    protein: 35,
    carbs: 52,
    fats: 17,
    cost: 52,
    prep_time: 16,
    primary_protein: 'chicken',
    is_hostel_friendly: 1,
    tags: ['non-veg', 'lean-protein', 'gym-cut'],
    ingredients: [
      { name: 'Chicken Breast Strips', qty: '110g', cost: 31 },
      { name: 'Capsicum & Onion Slices', qty: '80g', cost: 8 },
      { name: 'Atta (2 Rotis)', qty: '60g', cost: 3 },
      { name: 'Soy Sauce, Green Chilli & Oil', qty: '1 serving', cost: 10 }
    ],
    instructions: [
      'Stir fry chicken strips on high heat in 1 tsp oil with minced garlic.',
      'Add onion and bell peppers; toss with touch of soy and black pepper.',
      'Eat with 2 soft wheat rotis.'
    ]
  },
  {
    id: 46,
    name: 'Matar Mushroom Curry with 3 Rotis',
    meal_type: 'dinner',
    diet_type: 'vegan',
    calories: 480,
    protein: 18,
    carbs: 64,
    fats: 15,
    cost: 46,
    prep_time: 16,
    primary_protein: 'mushroom',
    is_hostel_friendly: 1,
    tags: ['vegan', 'low-calorie', 'restaurant-style'],
    ingredients: [
      { name: 'Fresh Button Mushrooms', qty: '100g', cost: 22 },
      { name: 'Green Peas', qty: '50g', cost: 7 },
      { name: 'Atta (3 Rotis)', qty: '85g', cost: 5 },
      { name: 'Onion-Tomato Masala & Oil', qty: '1 serving', cost: 12 }
    ],
    instructions: [
      'Sauté mushrooms until golden and juices evaporate.',
      'Add peas and spiced tomato sauce.',
      'Simmer 5 minutes. Serve with hot rotis.'
    ]
  },
  {
    id: 47,
    name: 'Yellow Moong Dal, 3 Rotis & Roasted Papad',
    meal_type: 'dinner',
    diet_type: 'vegan',
    calories: 480,
    protein: 18,
    carbs: 74,
    fats: 10,
    cost: 30,
    prep_time: 15,
    primary_protein: 'dal',
    is_hostel_friendly: 1,
    tags: ['vegan', 'soothing', 'light-night'],
    ingredients: [
      { name: 'Moong Dal (Yellow Split)', qty: '60g', cost: 8 },
      { name: 'Atta (3 Rotis)', qty: '85g', cost: 5 },
      { name: 'Urad Dal Papad (1 pc roasted)', qty: '1 pc', cost: 4 },
      { name: 'Jeera, Hing, Turmeric & Oil', qty: '1 serving', cost: 13 }
    ],
    instructions: [
      'Simmer moong dal with turmeric and salt.',
      'Add cumin-hing tadka.',
      'Dry roast papad on flame or induction; enjoy with rotis.'
    ]
  },
  {
    id: 48,
    name: 'Soy Keema Masala with Pav or 3 Rotis',
    meal_type: 'dinner',
    diet_type: 'vegan',
    calories: 540,
    protein: 34,
    carbs: 66,
    fats: 12,
    cost: 35,
    prep_time: 16,
    primary_protein: 'soya',
    is_hostel_friendly: 1,
    tags: ['street-style', 'protein-dense', 'vegan'],
    ingredients: [
      { name: 'Soya Granules (Dry)', qty: '55g', cost: 8 },
      { name: 'Atta (3 Rotis) or Pav', qty: '85g', cost: 6 },
      { name: 'Onion, Green Peas, Tomato & Pav Bhaji Masala', qty: '1 serving', cost: 16 },
      { name: 'Oil & Lemon', qty: '1 serving', cost: 5 }
    ],
    instructions: [
      'Boil soya granules for 3 minutes, rinse in cold water and press dry.',
      'Cook minced onions, tomatoes, and peas with pav bhaji masala.',
      'Mix in soya keema, cook 5 mins. Squeeze lemon and eat with rotis.'
    ]
  },
  {
    id: 49,
    name: 'Rajma Shami Kebab (Pan-Seared) & 2 Rotis',
    meal_type: 'dinner',
    diet_type: 'vegan',
    calories: 510,
    protein: 20,
    carbs: 70,
    fats: 14,
    cost: 36,
    prep_time: 20,
    primary_protein: 'rajma',
    is_hostel_friendly: 1,
    tags: ['vegan', 'gourmet-budget', 'fiber'],
    ingredients: [
      { name: 'Boiled Rajma Mashed', qty: '120g', cost: 14 },
      { name: 'Roasted Besan for Binding', qty: '25g', cost: 4 },
      { name: 'Atta (2 Rotis)', qty: '60g', cost: 3 },
      { name: 'Onion, Mint, Spices & Oil for pan-sear', qty: '1 serving', cost: 15 }
    ],
    instructions: [
      'Mash boiled rajma with roasted besan, chopped onion, mint, and garam masala into patties.',
      'Pan sear patties in 1 tsp oil until crusty brown.',
      'Wrap in warm rotis with mint chutney.'
    ]
  },
  {
    id: 50,
    name: 'Dahi Aloo with Jeera Rice & Sprouted Salad',
    meal_type: 'dinner',
    diet_type: 'veg',
    calories: 520,
    protein: 14,
    carbs: 84,
    fats: 12,
    cost: 32,
    prep_time: 15,
    primary_protein: 'curd',
    is_hostel_friendly: 1,
    tags: ['cooling', 'comfort', 'veg'],
    ingredients: [
      { name: 'Boiled Potatoes Cubed', qty: '120g', cost: 6 },
      { name: 'Fresh Dahi', qty: '120g', cost: 10 },
      { name: 'Rice for Jeera Rice', qty: '80g', cost: 5 },
      { name: 'Sprouted Moong Garnish', qty: '30g', cost: 4 },
      { name: 'Spices & Oil', qty: '1 serving', cost: 7 }
    ],
    instructions: [
      'Whisk curd with turmeric, coriander powder, and water.',
      'Pour over sautéed boiled potatoes, simmer on low heat without curdling.',
      'Serve over fragrant jeera rice with sprouted moong crunch.'
    ]
  }
];

module.exports = { SEED_RECIPES };
