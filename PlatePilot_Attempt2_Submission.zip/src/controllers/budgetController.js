/**
 * Budget Controller
 * Manages student budget profiler intake, macro requirement calculation, and persistence.
 */

const { calculateRDATargets } = require('../services/optimizerService');
const { getDatabase } = require('../config/database');

async function getRDAGoals(req, res, next) {
  try {
    const { fitnessGoal, weightKg } = req.query;
    const rda = calculateRDATargets(fitnessGoal || 'Muscle Gain', Number(weightKg) || 65);
    return res.status(200).json({ success: true, rda });
  } catch (err) {
    next(err);
  }
}

async function saveBudgetProfile(req, res, next) {
  try {
    const { userId, dailyBudget, dietPreference, fitnessGoal, weightKg } = req.body;
    const budgetNum = Number(dailyBudget) || 120;
    const goal = fitnessGoal || 'Muscle Gain';
    const diet = (dietPreference || 'veg').toLowerCase();
    const rda = calculateRDATargets(goal, Number(weightKg) || 65);

    const db = getDatabase();
    const insert = db.prepare(`
      INSERT INTO StudentBudgets (
        user_id, daily_budget, diet_preference, fitness_goal,
        target_calories, target_protein, target_carbs, target_fats
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = insert.run(
      userId || 'student_guest',
      budgetNum,
      diet,
      goal,
      rda.targetCalories,
      rda.targetProtein,
      rda.targetCarbs,
      rda.targetFats
    );

    return res.status(201).json({
      success: true,
      message: 'Student budget profile saved successfully',
      profileId: result.lastInsertRowid,
      rda
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getRDAGoals,
  saveBudgetProfile
};
