/**
 * Plan Controller
 * Handles meal plan generation, meal swaps, grocery list compilation, and plan persistence.
 */

const { generateOptimizedMealPlan } = require('../services/optimizerService');
const { getMealSwapAlternatives, executeMealSwap } = require('../services/mealSwapService');
const { generateWeeklyGroceryList } = require('../services/groceryService');
const { getDatabase } = require('../config/database');

async function optimizeMealPlan(req, res, next) {
  try {
    const result = generateOptimizedMealPlan(req.validatedBody);
    return res.status(200).json(result);
  } catch (err) {
    next(err);
  }
}

async function getSwapOptions(req, res, next) {
  try {
    const { currentMeals, slotKey, dailyBudget, targetDiet, priceMultiplier } = req.body;
    const alternatives = getMealSwapAlternatives({
      currentMeals,
      slotKey,
      dailyBudget: Number(dailyBudget) || 120,
      targetDiet,
      priceMultiplier: Number(priceMultiplier) || 1.0
    });
    return res.status(200).json({ success: true, slotKey, alternatives });
  } catch (err) {
    next(err);
  }
}

async function executeSwap(req, res, next) {
  try {
    const { currentPlan, slotKey, replacementRecipeId } = req.body;
    const updatedPlan = executeMealSwap({ currentPlan, slotKey, replacementRecipeId: Number(replacementRecipeId) });
    return res.status(200).json({ success: true, plan: updatedPlan });
  } catch (err) {
    next(err);
  }
}

async function getGroceryShoppingList(req, res, next) {
  try {
    const { meals, days, priceMultiplier } = req.body;
    if (!Array.isArray(meals) || meals.length === 0) {
      return res.status(400).json({ success: false, error: 'A valid meals array is required to generate grocery list.' });
    }
    const groceryList = generateWeeklyGroceryList(meals, Number(days) || 7, Number(priceMultiplier) || 1.0);
    return res.status(200).json({ success: true, groceryList });
  } catch (err) {
    next(err);
  }
}

async function saveMealPlan(req, res, next) {
  try {
    const { planName, plan } = req.body;
    if (!plan || !plan.totals || !plan.meals) {
      return res.status(400).json({ success: false, error: 'Invalid plan payload.' });
    }

    const db = getDatabase();
    const insert = db.prepare(`
      INSERT INTO MealPlans (
        plan_name, daily_budget, total_cost, total_calories, total_protein,
        total_carbs, total_fats, diet_preference, fitness_goal, meals_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = insert.run(
      planName || `Meal Plan - ${new Date().toLocaleDateString('en-IN')}`,
      plan.meta.dailyBudget,
      plan.totals.cost,
      plan.totals.calories,
      plan.totals.protein,
      plan.totals.carbs,
      plan.totals.fats,
      plan.meta.dietPreference,
      plan.meta.fitnessGoal,
      JSON.stringify(plan.meals)
    );

    return res.status(201).json({
      success: true,
      message: 'Meal plan saved successfully',
      planId: result.lastInsertRowid
    });
  } catch (err) {
    next(err);
  }
}

async function getSavedPlans(req, res, next) {
  try {
    const db = getDatabase();
    const plans = db.query('SELECT * FROM MealPlans ORDER BY created_at DESC LIMIT 20');
    return res.status(200).json({ success: true, plans });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  optimizeMealPlan,
  getSwapOptions,
  executeSwap,
  getGroceryShoppingList,
  saveMealPlan,
  getSavedPlans
};
