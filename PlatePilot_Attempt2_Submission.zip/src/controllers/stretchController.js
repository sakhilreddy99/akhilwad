/**
 * Stretch Controller
 * Powers:
 * 1. Hostel Mess Alternative Mode
 * 2. Pantry Leftover Optimizer
 * 3. Community Budget Recipe Feed & Upvoting
 */

const { getDatabase } = require('../config/database');
const { getCommonPantryItems, findPantryOptimizedRecipes } = require('../services/pantryService');

async function getHostelMessGuide(req, res, next) {
  try {
    const db = getDatabase();
    const rows = db.query('SELECT * FROM HostelMessMenu ORDER BY id ASC');

    const formatted = rows.map(r => {
      let supplements = [];
      try { supplements = JSON.parse(r.recommended_supplements_json); } catch (e) {}
      return {
        id: r.id,
        day: r.day_of_week,
        messMeal: r.mess_meal,
        messRating: r.mess_rating,
        actionPlan: r.action_plan,
        totalExtraCost: r.total_extra_cost,
        boostedProtein: r.boosted_protein,
        supplements
      };
    });

    return res.status(200).json({ success: true, count: formatted.length, schedule: formatted });
  } catch (err) {
    next(err);
  }
}

async function getPantryList(req, res, next) {
  try {
    const items = getCommonPantryItems();
    return res.status(200).json({ success: true, pantryItems: items });
  } catch (err) {
    next(err);
  }
}

async function optimizePantryLeftovers(req, res, next) {
  try {
    const { pantryItemIds, dietPreference } = req.body;
    const result = findPantryOptimizedRecipes({
      pantryItemIds: Array.isArray(pantryItemIds) ? pantryItemIds : [],
      dietPreference: dietPreference || 'non-veg'
    });
    return res.status(200).json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
}

async function getCommunityRecipes(req, res, next) {
  try {
    const db = getDatabase();
    const recipes = db.query('SELECT * FROM CommunityRecipes ORDER BY upvotes DESC, created_at DESC');
    return res.status(200).json({ success: true, count: recipes.length, recipes });
  } catch (err) {
    next(err);
  }
}

async function submitCommunityRecipe(req, res, next) {
  try {
    const {
      title, author_name, dorm_room, cost, calories, protein, prep_time, diet_type, ingredients, instructions
    } = req.body;

    const db = getDatabase();
    const insert = db.prepare(`
      INSERT INTO CommunityRecipes (
        title, author_name, dorm_room, cost, calories, protein,
        prep_time, diet_type, ingredients, instructions, upvotes, verified
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = insert.run(
      title,
      author_name,
      dorm_room || 'Campus Resident',
      Number(cost),
      Number(calories),
      Number(protein),
      Number(prep_time) || 10,
      diet_type || 'veg',
      ingredients,
      instructions,
      1,
      1
    );

    return res.status(201).json({
      success: true,
      message: 'Recipe shared to community board successfully!',
      recipeId: result.lastInsertRowid
    });
  } catch (err) {
    next(err);
  }
}

async function upvoteCommunityRecipe(req, res, next) {
  try {
    const { id } = req.params;
    const db = getDatabase();
    const update = db.prepare('UPDATE CommunityRecipes SET upvotes = upvotes + 1 WHERE id = ?');
    const result = update.run(id);

    if (result.changes === 0) {
      return res.status(404).json({ success: false, error: 'Recipe not found' });
    }

    const updated = db.get('SELECT * FROM CommunityRecipes WHERE id = ?', [id]);
    return res.status(200).json({ success: true, recipe: updated });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getHostelMessGuide,
  getPantryList,
  optimizePantryLeftovers,
  getCommunityRecipes,
  submitCommunityRecipe,
  upvoteCommunityRecipe
};
