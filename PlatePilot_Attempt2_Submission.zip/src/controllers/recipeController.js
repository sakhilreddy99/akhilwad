/**
 * Recipe Controller
 * Serves filterable Indian staple recipe catalog.
 */

const { getDatabase } = require('../config/database');

async function getAllRecipes(req, res, next) {
  try {
    const { meal_type, diet_type, max_cost, min_protein, hostel_only, search } = req.query;
    const db = getDatabase();

    let sql = 'SELECT * FROM IndianStapleRecipes WHERE 1=1';
    const params = [];

    if (meal_type) {
      sql += ' AND meal_type = ?';
      params.push(meal_type.toLowerCase());
    }
    if (diet_type) {
      if (diet_type.toLowerCase() === 'veg') {
        sql += " AND diet_type IN ('veg', 'vegan')";
      } else {
        sql += ' AND diet_type = ?';
        params.push(diet_type.toLowerCase());
      }
    }
    if (max_cost) {
      sql += ' AND cost <= ?';
      params.push(Number(max_cost));
    }
    if (min_protein) {
      sql += ' AND protein >= ?';
      params.push(Number(min_protein));
    }
    if (hostel_only === 'true' || hostel_only === '1') {
      sql += ' AND is_hostel_friendly = 1';
    }
    if (search) {
      sql += ' AND name LIKE ?';
      params.push(`%${search}%`);
    }

    sql += ' ORDER BY cost ASC';

    const recipes = db.query(sql, params);

    const parsed = recipes.map(r => {
      let ingredients = [];
      let instructions = [];
      let tags = [];
      try { ingredients = JSON.parse(r.ingredients_json); } catch (e) {}
      try { instructions = JSON.parse(r.instructions_json); } catch (e) {}
      try { tags = JSON.parse(r.tags_json); } catch (e) {}

      return {
        ...r,
        is_hostel_friendly: r.is_hostel_friendly === 1,
        ingredients,
        instructions,
        tags
      };
    });

    return res.status(200).json({
      success: true,
      count: parsed.length,
      recipes: parsed
    });
  } catch (err) {
    next(err);
  }
}

async function getRecipeById(req, res, next) {
  try {
    const { id } = req.params;
    const db = getDatabase();
    const recipe = db.get('SELECT * FROM IndianStapleRecipes WHERE id = ?', [id]);

    if (!recipe) {
      return res.status(404).json({ success: false, error: `Recipe with ID ${id} not found.` });
    }

    let ingredients = [];
    let instructions = [];
    let tags = [];
    try { ingredients = JSON.parse(recipe.ingredients_json); } catch (e) {}
    try { instructions = JSON.parse(recipe.instructions_json); } catch (e) {}
    try { tags = JSON.parse(recipe.tags_json); } catch (e) {}

    return res.status(200).json({
      success: true,
      recipe: {
        ...recipe,
        is_hostel_friendly: recipe.is_hostel_friendly === 1,
        ingredients,
        instructions,
        tags
      }
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getAllRecipes,
  getRecipeById
};
