/**
 * Database Layer for PlatePilot
 * Utilizes Node.js native SQLite (node:sqlite DatabaseSync) with parameterized queries,
 * transactions, auto-migration, and seed data initialization.
 */

const path = require('path');
const fs = require('fs');
const { SEED_RECIPES } = require('../data/seedRecipes');
const { SEED_INGREDIENTS } = require('../data/seedIngredients');
const { HOSTEL_MESS_GUIDE } = require('../data/seedHostelMess');

const DB_FILE = process.env.NODE_ENV === 'test'
  ? ':memory:'
  : path.join(__dirname, '..', '..', 'platepilot.db');

let dbInstance = null;

class DatabaseManager {
  constructor(dbPath = DB_FILE) {
    this.dbPath = dbPath;
    this.init();
  }

  init() {
    try {
      const { DatabaseSync } = require('node:sqlite');
      this.db = new DatabaseSync(this.dbPath);
      this.isNative = true;

      // WAL mode, busy timeout, and foreign keys for high concurrency and zero locks
      if (this.dbPath !== ':memory:') {
        try {
          this.db.exec('PRAGMA journal_mode = WAL;');
        } catch (e) {}
      }
      this.db.exec('PRAGMA busy_timeout = 5000;');
      this.db.exec('PRAGMA foreign_keys = ON;');
    } catch (err) {
      console.warn('Native node:sqlite not available, using JSON-backed persistence fallback.', err.message);
      this.isNative = false;
      this.memoryStore = {
        StudentBudgets: [],
        IndianStapleRecipes: [],
        NutrientCosts: [],
        MealPlans: [],
        HostelMessMenu: [],
        CommunityRecipes: [],
        PantryItems: []
      };
    }

    this.createTables();
    this.seedInitialData();
  }

  createTables() {
    if (this.isNative) {
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS StudentBudgets (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id TEXT NOT NULL,
          daily_budget REAL NOT NULL,
          diet_preference TEXT NOT NULL,
          fitness_goal TEXT NOT NULL,
          target_calories REAL NOT NULL,
          target_protein REAL NOT NULL,
          target_carbs REAL NOT NULL,
          target_fats REAL NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS IndianStapleRecipes (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          meal_type TEXT NOT NULL,
          diet_type TEXT NOT NULL,
          calories REAL NOT NULL,
          protein REAL NOT NULL,
          carbs REAL NOT NULL,
          fats REAL NOT NULL,
          cost REAL NOT NULL,
          prep_time INTEGER NOT NULL,
          primary_protein TEXT NOT NULL,
          is_hostel_friendly INTEGER DEFAULT 1,
          ingredients_json TEXT NOT NULL,
          instructions_json TEXT NOT NULL,
          tags_json TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS NutrientCosts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT UNIQUE NOT NULL,
          category TEXT NOT NULL,
          unit TEXT NOT NULL,
          unit_price REAL NOT NULL,
          bulk_size TEXT NOT NULL,
          bulk_price REAL NOT NULL,
          calories_per_100g REAL NOT NULL,
          protein_per_100g REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS MealPlans (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          plan_name TEXT,
          daily_budget REAL NOT NULL,
          total_cost REAL NOT NULL,
          total_calories REAL NOT NULL,
          total_protein REAL NOT NULL,
          total_carbs REAL NOT NULL,
          total_fats REAL NOT NULL,
          diet_preference TEXT NOT NULL,
          fitness_goal TEXT NOT NULL,
          meals_json TEXT NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS HostelMessMenu (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          day_of_week TEXT NOT NULL,
          mess_meal TEXT NOT NULL,
          mess_rating TEXT NOT NULL,
          action_plan TEXT NOT NULL,
          recommended_supplements_json TEXT NOT NULL,
          total_extra_cost REAL NOT NULL,
          boosted_protein TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS CommunityRecipes (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          author_name TEXT NOT NULL,
          dorm_room TEXT NOT NULL,
          cost REAL NOT NULL,
          calories REAL NOT NULL,
          protein REAL NOT NULL,
          prep_time INTEGER NOT NULL,
          diet_type TEXT NOT NULL,
          ingredients TEXT NOT NULL,
          instructions TEXT NOT NULL,
          upvotes INTEGER DEFAULT 1,
          verified INTEGER DEFAULT 1,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS PantryItems (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          item_name TEXT UNIQUE NOT NULL,
          category TEXT NOT NULL,
          default_unit TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_recipes_meal_type ON IndianStapleRecipes(meal_type);
        CREATE INDEX IF NOT EXISTS idx_recipes_diet_type ON IndianStapleRecipes(diet_type);
        CREATE INDEX IF NOT EXISTS idx_recipes_cost ON IndianStapleRecipes(cost);
      `);
    }
  }

  seedInitialData() {
    if (this.isNative) {
      // Check recipe count
      const countStmt = this.db.prepare('SELECT COUNT(*) as count FROM IndianStapleRecipes');
      const countResult = countStmt.get();

      if (countResult.count < 50) {
        // Clear and re-seed in a clean transaction
        this.db.exec('DELETE FROM IndianStapleRecipes;');
        this.db.exec('BEGIN IMMEDIATE TRANSACTION;');

        const insertRecipe = this.db.prepare(`
          INSERT INTO IndianStapleRecipes (
            id, name, meal_type, diet_type, calories, protein, carbs, fats, cost,
            prep_time, primary_protein, is_hostel_friendly, ingredients_json,
            instructions_json, tags_json
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        for (const r of SEED_RECIPES) {
          insertRecipe.run(
            r.id,
            r.name,
            r.meal_type,
            r.diet_type,
            r.calories,
            r.protein,
            r.carbs,
            r.fats,
            r.cost,
            r.prep_time,
            r.primary_protein,
            r.is_hostel_friendly,
            JSON.stringify(r.ingredients),
            JSON.stringify(r.instructions),
            JSON.stringify(r.tags)
          );
        }
        this.db.exec('COMMIT;');
      }

      // Check NutrientCosts
      const ingCountStmt = this.db.prepare('SELECT COUNT(*) as count FROM NutrientCosts');
      if (ingCountStmt.get().count < SEED_INGREDIENTS.length) {
        this.db.exec('DELETE FROM NutrientCosts;');
        this.db.exec('BEGIN IMMEDIATE TRANSACTION;');
        const insertIng = this.db.prepare(`
          INSERT INTO NutrientCosts (
            name, category, unit, unit_price, bulk_size, bulk_price, calories_per_100g, protein_per_100g
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `);
        for (const ing of SEED_INGREDIENTS) {
          insertIng.run(
            ing.name,
            ing.category,
            ing.unit,
            ing.unitPrice,
            ing.bulkSize,
            ing.bulkPrice,
            ing.caloriesPer100g,
            ing.proteinPer100g
          );
        }
        this.db.exec('COMMIT;');
      }

      // Check HostelMessMenu
      const messCountStmt = this.db.prepare('SELECT COUNT(*) as count FROM HostelMessMenu');
      if (messCountStmt.get().count < HOSTEL_MESS_GUIDE.length) {
        this.db.exec('DELETE FROM HostelMessMenu;');
        this.db.exec('BEGIN IMMEDIATE TRANSACTION;');
        const insertMess = this.db.prepare(`
          INSERT INTO HostelMessMenu (
            day_of_week, mess_meal, mess_rating, action_plan, recommended_supplements_json, total_extra_cost, boosted_protein
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `);
        for (const m of HOSTEL_MESS_GUIDE) {
          insertMess.run(
            m.day,
            m.messMeal,
            m.messRating,
            m.actionPlan,
            JSON.stringify(m.recommendedSupplements),
            m.totalExtraCost,
            m.boostedProtein
          );
        }
        this.db.exec('COMMIT;');
      }

      // Seed Initial Community Recipes if empty
      const commCountStmt = this.db.prepare('SELECT COUNT(*) as count FROM CommunityRecipes');
      if (commCountStmt.get().count === 0) {
        this.db.exec('BEGIN IMMEDIATE TRANSACTION;');
        const insertComm = this.db.prepare(`
          INSERT INTO CommunityRecipes (
            title, author_name, dorm_room, cost, calories, protein, prep_time, diet_type, ingredients, instructions, upvotes, verified
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        insertComm.run(
          'Kettle-Cooked Soya Keema Maggi Hack',
          'Rohan V.',
          'Hostel 4, Room 218',
          28,
          480,
          26,
          6,
          'vegan',
          '1 Pack Maggi (₹14), 40g Dry Soya Granules (₹6), 1/2 tsp Chaat Masala (₹2), Maggi Seasoning (₹6)',
          '1. Boil water in kettle. 2. Soak soya granules for 2 mins and drain. 3. Add noodles and seasoning. Simmer 3 mins for 26g hostel protein.',
          42,
          1
        );
        insertComm.run(
          'Double Egg Peanut Butter Roti Roll',
          'Ananya S.',
          'Girls Hostel 2, Room 104',
          32,
          490,
          24,
          5,
          'non-veg',
          '2 Boiled Eggs (₹14), 2 Ready Rotis (₹6), 1 tbsp Peanut Butter (₹8), Green Chillies & Chaat Masala (₹4)',
          'Spread peanut butter inside rotis, place mashed seasoned boiled eggs, roll up tightly and enjoy cold or warm.',
          38,
          1
        );
        insertComm.run(
          'Dorm Room Chana Sundal (Tamil Hostel Hack)',
          'Karthik N.',
          'Block C, Room 312',
          18,
          290,
          16,
          5,
          'vegan',
          'Soaked/Boiled Kala Chana (80g, ₹9), Grated Fresh Coconut (₹4), Mustard Seeds & Curry Leaves (₹3), Lemon (₹2)',
          'Temper mustard seeds and curry leaves in single dorm pan. Toss boiled chana with salt and fresh coconut.',
          29,
          1
        );
        this.db.exec('COMMIT;');
      }
    } else {
      this.memoryStore.IndianStapleRecipes = [...SEED_RECIPES];
      this.memoryStore.NutrientCosts = [...SEED_INGREDIENTS];
      this.memoryStore.HostelMessMenu = [...HOSTEL_MESS_GUIDE];
    }
  }

  query(sql, params = []) {
    if (this.isNative) {
      const stmt = this.db.prepare(sql);
      return stmt.all(...params);
    }
    return [];
  }

  get(sql, params = []) {
    if (this.isNative) {
      const stmt = this.db.prepare(sql);
      return stmt.get(...params);
    }
    return null;
  }

  run(sql, params = []) {
    if (this.isNative) {
      const stmt = this.db.prepare(sql);
      return stmt.run(...params);
    }
    return { changes: 1, lastInsertRowid: Date.now() };
  }
}

function getDatabase() {
  if (!dbInstance) {
    dbInstance = new DatabaseManager();
  }
  return dbInstance;
}

module.exports = { getDatabase, DatabaseManager };
